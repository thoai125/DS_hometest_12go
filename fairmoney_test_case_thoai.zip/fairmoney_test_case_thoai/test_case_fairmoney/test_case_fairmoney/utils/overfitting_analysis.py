import numpy as np
import pandas as pd
from catboost import CatBoostClassifier, Pool
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns


def detect_overfitting_features_catboost(
    train_X,
    train_y,
    val_X,
    val_y,
    test_X,
    test_y,
    feat_num=None,
    feat_cat=None,
    iterations=1000,
    early_stopping_rounds=50,
):
    """
    Detect features that cause overfitting in CatBoost by analyzing:
    1. Feature importance differences between train/val
    2. Performance drop when removing features
    3. Individual feature contribution to overfitting

    Args:
        train_X, val_X, test_X: Feature datasets
        train_y, val_y, test_y: Target datasets
        feat_num: List of numerical feature names (optional)
        feat_cat: List of categorical feature names (optional)
        iterations: Number of boosting iterations
        early_stopping_rounds: Early stopping rounds

    Returns:
        DataFrame with overfitting metrics per feature, baseline model
    """

    print("=" * 60)
    print("DETECTING OVERFITTING FEATURES IN CATBOOST")
    print("=" * 60)

    # Auto-detect feature types if not provided
    if feat_cat is None:
        feat_cat = train_X.select_dtypes(
            include=["object", "category"]
        ).columns.tolist()
        print(f"Auto-detected {len(feat_cat)} categorical features")

    if feat_num is None:
        feat_num = [col for col in train_X.columns if col not in feat_cat]
        print(f"Auto-detected {len(feat_num)} numerical features")

    print(f"\nDataset info:")
    print(f"  Total features: {train_X.shape[1]}")
    print(f"  Numerical features: {len(feat_num)}")
    print(f"  Categorical features: {len(feat_cat)}")
    print(f"  Categorical: {feat_cat}")

    # Step 1: Create Pool objects for baseline model
    print("\n1. Creating Pool objects and training baseline model...")

    train_pool = Pool(data=train_X, label=train_y, cat_features=feat_cat)

    val_pool = Pool(data=val_X, label=val_y, cat_features=feat_cat)

    test_pool = Pool(data=test_X, label=test_y, cat_features=feat_cat)

    baseline_model = CatBoostClassifier(
        iterations=iterations,
        learning_rate=0.05,
        depth=5,
        random_seed=42,
        verbose=False,
        early_stopping_rounds=early_stopping_rounds,
        eval_metric="AUC:use_weights=False",  # AUC for imbalanced data
        auto_class_weights="Balanced",  # Handle class imbalance
    )

    baseline_model.fit(train_pool, eval_set=val_pool, verbose=100)

    # Baseline predictions
    pred_train_base = baseline_model.predict_proba(train_pool)[:, 1]
    pred_val_base = baseline_model.predict_proba(val_pool)[:, 1]
    pred_test_base = baseline_model.predict_proba(test_pool)[:, 1]

    auc_train_base = roc_auc_score(train_y, pred_train_base)
    auc_val_base = roc_auc_score(val_y, pred_val_base)
    auc_test_base = roc_auc_score(test_y, pred_test_base)

    print(f"\nBaseline Performance:")
    print(f"  Train AUC: {auc_train_base:.4f}")
    print(f"  Val AUC:   {auc_val_base:.4f}")
    print(f"  Test AUC:  {auc_test_base:.4f}")
    print(f"  Overfit (Train-Val): {auc_train_base - auc_val_base:.4f}")

    # Step 2: Get feature importances
    print("\n2. Analyzing feature importances...")

    feature_importance = baseline_model.get_feature_importance()
    feature_names = train_X.columns.tolist()

    # Step 3: Test removal of each feature
    print("\n3. Testing individual feature removal...")

    results = []

    for i, feature in enumerate(feature_names):
        is_categorical = feature in feat_cat
        feat_type = "categorical" if is_categorical else "numerical"
        print(f"  Testing feature {i+1}/{len(feature_names)}: {feature} ({feat_type})")

        # Create subset without this feature
        features_subset = [f for f in feature_names if f != feature]

        # Update categorical feature list for subset
        feat_cat_subset = [f for f in feat_cat if f in features_subset]

        try:
            # Create Pool objects for subset
            train_pool_subset = Pool(
                data=train_X[features_subset],
                label=train_y,
                cat_features=feat_cat_subset,
            )

            val_pool_subset = Pool(
                data=val_X[features_subset], label=val_y, cat_features=feat_cat_subset
            )

            test_pool_subset = Pool(
                data=test_X[features_subset], label=test_y, cat_features=feat_cat_subset
            )

            # Train model without this feature
            model = CatBoostClassifier(
                iterations=iterations,
                learning_rate=0.1,
                depth=5,
                random_seed=42,
                verbose=False,
                early_stopping_rounds=early_stopping_rounds,
                eval_metric="AUC:use_weights=False",  # AUC for imbalanced data
                auto_class_weights="Balanced",  # Handle class imbalance
            )

            model.fit(
                train_pool_subset,
                eval_set=val_pool_subset,
                verbose=False,
            )

            # Get predictions
            pred_train = model.predict_proba(train_pool_subset)[:, 1]
            pred_val = model.predict_proba(val_pool_subset)[:, 1]
            pred_test = model.predict_proba(test_pool_subset)[:, 1]

            # Calculate metrics
            auc_train = roc_auc_score(train_y, pred_train)
            auc_val = roc_auc_score(val_y, pred_val)
            auc_test = roc_auc_score(test_y, pred_test)

            # Calculate changes
            train_change = auc_train - auc_train_base
            val_change = auc_val - auc_val_base
            test_change = auc_test - auc_test_base

            overfit_before = auc_train_base - auc_val_base
            overfit_after = auc_train - auc_val
            overfit_reduction = overfit_before - overfit_after

            results.append(
                {
                    "feature": feature,
                    "feature_type": feat_type,
                    "importance": feature_importance[i],
                    "AUC_train": auc_train,
                    "AUC_val": auc_val,
                    "AUC_test": auc_test,
                    "train_change": train_change,
                    "val_change": val_change,
                    "test_change": test_change,
                    "overfit_before": overfit_before,
                    "overfit_after": overfit_after,
                    "overfit_reduction": overfit_reduction,
                    "overfit_score": overfit_reduction / (abs(val_change) + 0.001),
                }
            )

            print(
                f"    Train: {auc_train:.4f} ({train_change:+.4f}), Val: {auc_val:.4f} ({val_change:+.4f}), Test: {auc_test:.4f} ({test_change:+.4f})"
            )

        except Exception as e:
            print(f"    Error: {str(e)}")
            continue

    # Create results DataFrame
    df_results = pd.DataFrame(results)

    # Step 4: Identify overfitting features
    print("\n" + "=" * 60)
    print("OVERFITTING FEATURE ANALYSIS")
    print("=" * 60)

    # Features that reduce overfitting when removed
    overfitting_features = df_results[
        (df_results["overfit_reduction"] > 0.001) & (df_results["val_change"] > -0.01)
    ].sort_values("overfit_reduction", ascending=False)

    print(f"\n🔴 OVERFITTING FEATURES (reduce when removed):")
    print(f"Found {len(overfitting_features)} features")
    if len(overfitting_features) > 0:
        print(
            overfitting_features[
                [
                    "feature",
                    "feature_type",
                    "importance",
                    "overfit_reduction",
                    "val_change",
                    "test_change",
                ]
            ].to_string(index=False)
        )

    # Separate analysis by feature type
    print(f"\n📊 BREAKDOWN BY FEATURE TYPE:")
    for feat_type in ["numerical", "categorical"]:
        type_df = df_results[df_results["feature_type"] == feat_type]
        type_overfit = type_df[
            (type_df["overfit_reduction"] > 0.001) & (type_df["val_change"] > -0.01)
        ]
        print(
            f"\n  {feat_type.upper()}: {len(type_overfit)}/{len(type_df)} features cause overfitting"
        )
        if len(type_overfit) > 0:
            print(
                f"  Top offenders: {type_overfit.nlargest(3, 'overfit_reduction')['feature'].tolist()}"
            )

    # Features that are important but hurt generalization
    high_importance_overfit = df_results[
        (df_results["importance"] > df_results["importance"].median())
        & (df_results["val_change"] > 0)
    ].sort_values("val_change", ascending=False)

    print(f"\n⚠️  HIGH IMPORTANCE BUT HURT GENERALIZATION:")
    print(f"Found {len(high_importance_overfit)} features")
    if len(high_importance_overfit) > 0:
        print(
            high_importance_overfit[
                ["feature", "feature_type", "importance", "val_change", "test_change"]
            ]
            .head(10)
            .to_string(index=False)
        )

    # Sort by overfit score
    df_results = df_results.sort_values("overfit_score", ascending=False)

    return df_results, baseline_model


def plot_overfitting_analysis(df_results, top_n=20):
    """
    Visualize overfitting feature analysis with feature type distinction
    """
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))

    # Color mapping for feature types
    colors = {"numerical": "blue", "categorical": "orange"}
    df_results["color"] = df_results["feature_type"].map(colors)

    # 1. Overfit Reduction vs Validation Change
    ax1 = axes[0, 0]
    for feat_type, color in colors.items():
        mask = df_results["feature_type"] == feat_type
        ax1.scatter(
            df_results[mask]["val_change"],
            df_results[mask]["overfit_reduction"],
            c=color,
            s=100,
            alpha=0.6,
            label=feat_type,
        )
    ax1.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax1.axvline(x=0, color="gray", linestyle="--", alpha=0.5)
    ax1.set_xlabel("Validation AUC Change (when feature removed)")
    ax1.set_ylabel("Overfitting Reduction")
    ax1.set_title("Overfitting vs Validation Impact")
    ax1.legend()

    # Annotate top overfitting features
    top_overfit = df_results.nlargest(5, "overfit_reduction")
    for _, row in top_overfit.iterrows():
        ax1.annotate(
            row["feature"][:15],
            (row["val_change"], row["overfit_reduction"]),
            fontsize=8,
            alpha=0.7,
        )

    # 2. Top Overfitting Features
    ax2 = axes[0, 1]
    top_features = df_results.nlargest(top_n, "overfit_reduction")
    colors_bar = [colors[ft] for ft in top_features["feature_type"]]
    ax2.barh(
        range(len(top_features)), top_features["overfit_reduction"], color=colors_bar
    )
    ax2.set_yticks(range(len(top_features)))
    ax2.set_yticklabels(
        [
            f"{row['feature']} ({row['feature_type'][0].upper()})"
            for _, row in top_features.iterrows()
        ]
    )
    ax2.set_xlabel("Overfitting Reduction")
    ax2.set_title(f"Top {top_n} Features by Overfitting Reduction")
    ax2.invert_yaxis()

    # 3. Feature Importance vs Overfit Score by Type
    ax3 = axes[1, 0]
    for feat_type, color in colors.items():
        mask = df_results["feature_type"] == feat_type
        ax3.scatter(
            df_results[mask]["importance"],
            df_results[mask]["overfit_score"],
            alpha=0.6,
            s=100,
            c=color,
            label=feat_type,
        )
    ax3.set_xlabel("Feature Importance")
    ax3.set_ylabel("Overfit Score")
    ax3.set_title("Feature Importance vs Overfitting Tendency")
    ax3.legend()

    # 4. Train vs Val Change
    ax4 = axes[1, 1]
    for feat_type, color in colors.items():
        mask = df_results["feature_type"] == feat_type
        ax4.scatter(
            df_results[mask]["train_change"],
            df_results[mask]["val_change"],
            c=color,
            s=100,
            alpha=0.6,
            label=feat_type,
        )
    ax4.plot([-0.1, 0.1], [-0.1, 0.1], "k--", alpha=0.3)
    ax4.set_xlabel("Train AUC Change")
    ax4.set_ylabel("Val AUC Change")
    ax4.set_title("Train vs Validation Impact")
    ax4.legend()

    plt.tight_layout()
    plt.show()