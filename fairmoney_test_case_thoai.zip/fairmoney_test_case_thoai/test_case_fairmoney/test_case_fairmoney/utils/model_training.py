import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
import joblib
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split, StratifiedKFold
from typing import Dict, Any
import statsmodels.api as sm

from typing import Dict, Any
from sklearn.base import BaseEstimator

from catboost import CatBoostClassifier
from sklearn.metrics import roc_auc_score, average_precision_score

def rf_training(
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
    n_splits: int = 5,
) -> Dict[str, Any]:
    """
    This function trains a Random Forest model with StratifiedKFold cross-validation strategy.

    Args:
        X_train (pd.DataFrame): The training data.
        X_test (pd.DataFrame): The test data.
        y_train (pd.Series): The target for training data.
        y_test (pd.Series): The target for test data.
        n_splits (int, optional): n_splits for StratifiedKFold. Defaults to 5.

    Returns:
        Dict[str, Any]:
            prediction (np.ndarray): The prediction on the test data.
            oof (np.ndarray): The out-of-fold prediction.
            model (List[RandomForestClassifier]): The list of trained models by StratifiedKFold cross-validation strategy.
    """
    kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=1)
    oof_predictions = np.zeros(len(X_train))
    test_predictions = np.zeros(len(X_test))
    models = []

    for fold, (train_index, valid_index) in enumerate(kf.split(X_train, y_train)):
        X_train_fold, y_train_fold = (
            X_train.iloc[train_index],
            y_train.iloc[train_index],
        )
        X_valid_fold, y_valid_fold = (
            X_train.iloc[valid_index],
            y_train.iloc[valid_index],
        )

        model = RandomForestClassifier(
            criterion="gini",
            max_depth=15,
            max_features="log2",
            min_samples_leaf=10,
            n_estimators=500,
            n_jobs=-1,
            random_state=5,
        )

        model.fit(X_train_fold, y_train_fold)
        models.append(model)

        oof_predictions[valid_index] = model.predict_proba(X_valid_fold)[:, 1]
        fold_test_predictions = model.predict_proba(X_test)[:, 1]
        test_predictions += fold_test_predictions / n_splits

        print(f"Fold {fold + 1}")
        print(
            f"AUC on validation fold: {roc_auc_score(y_valid_fold, oof_predictions[valid_index]):.3f}"
        )
        print(f"AUC on test data: {roc_auc_score(y_test, fold_test_predictions):.3f}")

    print("-" * 30)
    print(f"CV AUC: {roc_auc_score(y_train, oof_predictions):.3f}")
    print(f"Test AUC: {roc_auc_score(y_test, test_predictions):.3f}")

    return {"prediction": test_predictions, "oof": oof_predictions, "model": models}


def lr_training(
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
    n_splits: int = 3,
    model_name: str = None,
    model_path: str = None
) -> Dict[str, Any]:
    """
    This function trains a LogisticRegression model with StratifiedKFold cross-validation strategy.

    Args:
        X_train (pd.DataFrame): The training data.
        X_test (pd.DataFrame): The test data.
        y_train (pd.Series): The target for training data.
        y_test (pd.Series): The target for test data.
        n_splits (int, optional): n_splits for StratifiedKFold. Defaults to 3.
        model_name (str, optional): Name for the saved model files. Defaults to "WO_EXP".

    Returns:
        Dict[str, Any]:
            prediction (np.ndarray): The prediction on the test data.
            oof (np.ndarray): The out-of-fold prediction.
            model (List[LogisticRegression]): The list of trained models by StratifiedKFold cross-validation strategy.
            train_prediction (np.ndarray): The in-sample prediction.
            AUC_test (float): The AUC score on the test data.
            AUC_val (float): The AUC score on the validation data.
    """
    kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=1)
    oof_predictions = np.zeros(len(X_train))
    test_predictions = np.zeros(len(X_test))
    train_predictions = np.zeros(len(X_train))
    models = []

    for fold, (train_index, valid_index) in enumerate(kf.split(X_train, y_train)):
        X_train_fold, y_train_fold = (
            X_train.iloc[train_index],
            y_train.iloc[train_index],
        )
        X_valid_fold, y_valid_fold = (
            X_train.iloc[valid_index],
            y_train.iloc[valid_index],
        )

        model = LogisticRegression(penalty="l2", C=0.1, max_iter=1000)
        model.fit(X_train_fold, y_train_fold)
        models.append(model)

        # Save the model
        if model_name:
            joblib.dump(model, model_path /f"LR_fold_{fold}_{model_name}.pkl")

        oof_predictions[valid_index] = model.predict_proba(X_valid_fold)[:, 1]
        fold_test_predictions = model.predict_proba(X_test)[:, 1]
        test_predictions += fold_test_predictions / n_splits
        train_predictions += model.predict_proba(X_train)[:, 1] / n_splits

        print(f"Fold {fold + 1}")
        print(
            f"AUC on train: {roc_auc_score(y_train_fold, model.predict_proba(X_train_fold)[:, 1]):.3f}"
        )
        print(
            f"AUC on val: {roc_auc_score(y_valid_fold, oof_predictions[valid_index]):.3f}"
        )
        print(f"AUC on test: {roc_auc_score(y_test, fold_test_predictions):.3f}")

    print("--------------------------")
    print(f"Train AUC: {roc_auc_score(y_train, train_predictions):.3f}")
    print(f"CV AUC: {roc_auc_score(y_train, oof_predictions):.3f}")
    print(f"Test AUC: {roc_auc_score(y_test, test_predictions):.3f}")

    return {
        "prediction": test_predictions,
        "oof": oof_predictions,
        "model": models,
        "train_prediction": train_predictions,
        "AUC_test": roc_auc_score(y_test, test_predictions),
        "AUC_val": roc_auc_score(y_train, oof_predictions),
    }


def print_coef_lr(
    lr: BaseEstimator,
    df_train: pd.DataFrame,
    train_target: pd.Series,
    p_value_show: bool = True,
    n_fold: int = 3
) -> pd.DataFrame:
    """
    Print the coefficients of the logistic regression model along with statistical information.

    Args:
        lr (BaseEstimator): The logistic regression model.
        df_train (pd.DataFrame): The training data.
        train_target (pd.Series): The target for training data.
        p_value_show (bool, optional): Whether to show p-values. Defaults to True.

    Returns:
        pd.DataFrame: DataFrame containing features, model coefficients, average coefficient,
                      standard deviation, and optionally p-values.
    """
    # Extract coefficients for each model
    coef_dict = {
        f"model_{i+1}": np.round(lr[f"model"][i].coef_[0], n_fold) for i in range(n_fold)
    }
    df_lr_woe = pd.DataFrame({"features": df_train.columns, **coef_dict})

    # Calculate average and standard deviation of coefficients
    
    df_lr_woe["avg"] = df_lr_woe[[f"model_{i+1}" for i in range(n_fold)]].abs().mean(axis=1)
    df_lr_woe["std"] = df_lr_woe[[f"model_{i+1}" for i in range(n_fold)]].std(axis=1)

    # Sort by average coefficient
    df_lr_woe = df_lr_woe.sort_values(by="avg", ascending=False)

    # Optionally add p-values
    if p_value_show:
        model = sm.OLS(train_target, df_train).fit()
        df_pvalue = pd.DataFrame(
            {"features": df_train.columns, "p_value": np.round(model.pvalues, 3)}
        )
        df_lr_woe = df_lr_woe.merge(df_pvalue, how="left", on="features")

    return df_lr_woe


import statsmodels.api as sm
from sklearn.base import BaseEstimator


def print_coef_single_lr(
    lr: BaseEstimator,
    df_train: pd.DataFrame,
    train_target: pd.Series,
    p_value_show: bool = True,
    n_fold: int = 3,
) -> pd.DataFrame:
    """
    Print the coefficients of the logistic regression model along with statistical information.

    Args:
        lr (BaseEstimator): The logistic regression model.
        df_train (pd.DataFrame): The training data.
        train_target (pd.Series): The target for training data.
        p_value_show (bool, optional): Whether to show p-values. Defaults to True.

    Returns:
        pd.DataFrame: DataFrame containing features, model coefficients, average coefficient,
                      standard deviation, and optionally p-values.
    """
    # Extract coefficients for each model

    # Calculate average and standard deviation of coefficients
    if n_fold > 1:
        coef_dict = {
            f"model_{i+1}": np.round(lr[f"model"][i].coef_[0], n_fold)
            for i in range(n_fold)
        }
        df_lr_woe = pd.DataFrame({"features": df_train.columns, **coef_dict})
        df_lr_woe["avg"] = (
            df_lr_woe[[f"model_{i+1}" for i in range(n_fold)]].abs().mean(axis=1)
        )
        df_lr_woe["std"] = df_lr_woe[[f"model_{i+1}" for i in range(n_fold)]].std(
            axis=1
        )
        # Sort by average coefficient
        df_lr_woe = df_lr_woe.sort_values(by="avg", ascending=False)
    else:
        df_lr_woe = pd.DataFrame({"features": df_train.columns, "coef": lr.coef_[0]})
        df_lr_woe = df_lr_woe.sort_values(by="coef", ascending=True)
    # Optionally add p-values
    if p_value_show:
        model = sm.OLS(train_target, df_train).fit()
        df_pvalue = pd.DataFrame(
            {"features": df_train.columns, "p_value": np.round(model.pvalues, 3)}
        )
        df_lr_woe = df_lr_woe.merge(df_pvalue, how="left", on="features")

    return df_lr_woe

def train_catboost_model(
    train_pool,
    val_pool,
    test_pool,
    model_params=None,
    training_params=None,
    verbose=True,
):
    """
    Train a CatBoost classifier with comprehensive performance evaluation.

    Parameters:
    -----------
    train_pool : catboost.Pool
        Training data pool (includes features, labels, and categorical features)
    val_pool : catboost.Pool
        Validation data pool
    test_pool : catboost.Pool
        Test data pool
    model_params : dict, optional
        CatBoost model parameters. If None, uses balanced defaults
    training_params : dict, optional
        Training parameters (early_stopping_rounds, plot, etc.)
    verbose : bool, default=True
        Whether to print detailed progress and results

    Returns:
    --------
    dict : Dictionary containing:
        - 'model': Trained CatBoost model
        - 'metrics': DataFrame with performance metrics for all datasets
        - 'predictions': Dictionary with predictions for train/val/test
        - 'feature_importance': Feature importance DataFrame
    """

    # Set default model parameters
    if model_params is None:
        model_params = {
            "iterations": 500,
            "learning_rate": 0.1,
            "depth": 6,
            "loss_function": "Logloss",
            "eval_metric": "AUC:use_weights=False",
            "auto_class_weights": "Balanced",
            "verbose": 100,
            "random_seed": 42,
        }

    # Set default training parameters
    if training_params is None:
        training_params = {
            "use_best_model": True,
            "early_stopping_rounds": 50,
            "plot": True,
        }

    # Extract information from pools
    n_train = train_pool.num_row()
    n_val = val_pool.num_row()
    n_test = test_pool.num_row()
    n_features = train_pool.num_col()

    # Get labels from pools
    y_train = train_pool.get_label()
    y_val = val_pool.get_label()
    y_test = test_pool.get_label()

    # Calculate class distribution
    train_positive_rate = np.mean(y_train)

    # Print header
    if verbose:
        print("\n" + "=" * 60)
        print("🚀 CATBOOST MODEL TRAINING")
        print("=" * 60)

        print(f"\n📋 Model Configuration:")
        print(f"   Iterations:       {model_params.get('iterations', 'N/A')}")
        print(f"   Learning Rate:    {model_params.get('learning_rate', 'N/A')}")
        print(f"   Tree Depth:       {model_params.get('depth', 'N/A')}")
        print(f"   Loss Function:    {model_params.get('loss_function', 'N/A')}")
        print(f"   Class Weights:    {model_params.get('auto_class_weights', 'N/A')}")

        print(f"\n📊 Dataset Information:")
        print(f"   Training samples:    {n_train:,}")
        print(f"   Validation samples:  {n_val:,}")
        print(f"   Test samples:        {n_test:,}")
        print(f"   Total features:      {n_features}")

        print(f"\n⚖️  Class Distribution (Train):")
        print(f"   Positive class: {train_positive_rate:.2%}")
        print(f"   Negative class: {1-train_positive_rate:.2%}")

    # Initialize model
    if verbose:
        print(f"\n🎯 Initializing CatBoost model...")

    model = CatBoostClassifier(**model_params)

    # Train model
    if verbose:
        print(f"\n🏋️  Training model...")
        print(
            f"   Early stopping:   {training_params.get('early_stopping_rounds', 'Disabled')}"
        )
        print(
            f"   Best model:       {'Yes' if training_params.get('use_best_model') else 'No'}"
        )
        print("-" * 60)

    model.fit(train_pool, eval_set=[val_pool], **training_params)

    # Generate predictions
    if verbose:
        print(f"\n🔮 Generating predictions...")

    y_pred_train = model.predict(train_pool, prediction_type="Probability")[:, 1]
    y_pred_val = model.predict(val_pool, prediction_type="Probability")[:, 1]
    y_pred_test = model.predict(test_pool, prediction_type="Probability")[:, 1]

    predictions = {"train": y_pred_train, "val": y_pred_val, "test": y_pred_test}

    # Calculate metrics
    if verbose:
        print(f"\n📊 PERFORMANCE METRICS")
        print("=" * 60)

    metrics_data = []

    datasets = [
        ("Train", y_train, y_pred_train),
        ("Validation", y_val, y_pred_val),
        ("Test", y_test, y_pred_test),
    ]

    for dataset_name, y_true, y_pred in datasets:
        # Calculate metrics
        roc_auc = roc_auc_score(y_true, y_pred)
        pr_auc = average_precision_score(y_true, y_pred)
        baseline = np.mean(y_true)
        lift = (pr_auc / baseline - 1) * 100

        # Store metrics
        metrics_data.append(
            {
                "dataset": dataset_name,
                "roc_auc": roc_auc,
                "pr_auc": pr_auc,
                "baseline": baseline,
                "lift_pct": lift,
            }
        )

        # Print metrics
        if verbose:
            print(f"\n🎯 {dataset_name} Set:")
            print(f"   ROC-AUC:      {roc_auc:.4f}")
            print(f"   PR-AUC:       {pr_auc:.4f}")
            print(f"   Baseline:     {baseline:.4f}")
            print(f"   Lift:         {lift:+.1f}% over random")

    # Create metrics DataFrame
    df_metrics = pd.DataFrame(metrics_data)

    # Get feature importance
    feature_importance = model.get_feature_importance(train_pool)
    feature_names = train_pool.get_feature_names()

    # Determine feature types if available
    cat_feature_indices = train_pool.get_cat_feature_indices()
    feature_types = [
        "categorical" if i in cat_feature_indices else "numerical"
        for i in range(len(feature_names))
    ]

    df_feature_importance = pd.DataFrame(
        {
            "feature": feature_names,
            "importance": feature_importance,
            "feature_type": feature_types,
        }
    ).sort_values("importance", ascending=False)

    # Print summary
    if verbose:
        print(f"\n{'='*60}")
        print("✅ MODEL TRAINING COMPLETED")
        print("=" * 60)

        print(f"\n🏆 Best Performance (Validation):")
        val_metrics = df_metrics[df_metrics["dataset"] == "Validation"].iloc[0]
        print(f"   ROC-AUC: {val_metrics['roc_auc']:.4f}")
        print(f"   PR-AUC:  {val_metrics['pr_auc']:.4f}")

        print(f"\n🔝 Top 10 Most Important Features:")
        for idx, row in df_feature_importance.head(10).iterrows():
            print(
                f"   {row['feature'][:30]:<30} {row['importance']:>8.2f}  ({row['feature_type']})"
            )

        print(f"\n💾 Model saved in memory and ready for predictions")
        print("=" * 60 + "\n")

    # Return comprehensive results
    return {
        "model": model,
        "metrics": df_metrics,
        "predictions": predictions,
        "feature_importance": df_feature_importance,
    }

import matplotlib.pyplot as plt


def analyze_feature_importance_cb(
    model, pool, top_n=10, figsize=(10, 8), plot=True, verbose=True
):
    """
    Analyze and visualize feature importance from a trained CatBoost model.

    Parameters:
    -----------
    model : CatBoostClassifier
        Trained CatBoost model
    pool : catboost.Pool
        Data pool (used to extract feature names)
    top_n : int, default=10
        Number of top features to highlight
    figsize : tuple, default=(10, 8)
        Figure size for plot
    plot : bool, default=True
        Whether to generate visualization
    verbose : bool, default=True
        Whether to print feature importance

    Returns:
    --------
    pd.DataFrame : Feature importance sorted by importance score
    """

    # Extract feature importance
    feature_importance = model.get_feature_importance()
    feature_names = pool.get_feature_names()

    # Create DataFrame
    df_importance = pd.DataFrame(
        {"feature": feature_names, "importance": feature_importance}
    ).sort_values("importance", ascending=False)

    # Print top features
    if verbose:
        print("\n" + "=" * 50)
        print(f"📊 TOP {top_n} MOST IMPORTANT FEATURES")
        print("=" * 50)
        for idx, row in df_importance.head(top_n).iterrows():
            print(f"   {row['feature']:<30} {row['importance']:>8.2f}")
        print("=" * 50 + "\n")

    # Plot feature importance
    if plot:
        # Sort for horizontal bar plot
        df_plot = df_importance.sort_values("importance", ascending=True)
        top_features = df_importance.head(top_n)["feature"].values

        # Create colors
        colors = [
            "lightcoral" if x in top_features else "lightblue"
            for x in df_plot["feature"]
        ]

        # Plot
        plt.figure(figsize=figsize)
        plt.barh(df_plot["feature"], df_plot["importance"], color=colors)
        plt.xlabel("Feature Importance Score", fontsize=12)
        plt.title("CatBoost Feature Importance", fontsize=14, fontweight="bold")
        plt.grid(True, alpha=0.3, axis="x")
        plt.tight_layout()
        plt.show()

    return df_importance