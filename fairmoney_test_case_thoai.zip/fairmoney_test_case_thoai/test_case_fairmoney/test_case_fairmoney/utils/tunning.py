from typing import Dict, Any
import numpy as np
from catboost import CatBoostClassifier, Pool
from sklearn.metrics import precision_recall_curve, roc_curve, auc
from optuna import Trial, create_study
from optuna.pruners import MedianPruner
from optuna.storages import JournalStorage, JournalFileStorage
from optuna.integration import CatBoostPruningCallback

# Configuration
SEED = 42
N_TRIALS = 100
EARLY_STOPPING_ROUNDS = 50
N_WARMUP_STEPS = 5

rng = np.random.default_rng(SEED)

BASE_PARAMS = {
    "learning_rate": 0.1,
    "loss_function": "Logloss",
    "iterations": 200,
    "depth": 5,
    "eval_metric": "AUC:use_weights=false",
    "l2_leaf_reg": 5,
    "auto_class_weights": "Balanced",
    "random_seed": SEED,
    "boosting_type": "Ordered",
    "bootstrap_type": "MVS",
    "verbose": False,
}


class CatBoostOptimizer:
    """Handles CatBoost model optimization using Optuna."""

    def __init__(
        self,
        train_pool: Pool,
        val_pool: Pool,
        target_column: str,
        base_params: Dict[str, Any],
    ):
        self.train_pool = train_pool
        self.val_pool = val_pool
        self.target_column = target_column
        self.base_params = base_params

    def get_score_prauc(self, model: CatBoostClassifier) -> float:
        """Calculate PR-AUC score."""
        y_pred = model.predict_proba(self.val_pool)[:, 1]
        y_true = self.val_pool.get_label()
        precision, recall, _ = precision_recall_curve(y_true, y_pred)
        return float(auc(recall, precision))

    def get_score_rocauc(self, model: CatBoostClassifier) -> float:
        """Calculate ROC-AUC score."""
        y_pred = model.predict_proba(self.val_pool)[:, 1]
        y_true = self.val_pool.get_label()
        fpr, tpr, _ = roc_curve(y_true, y_pred)
        return float(auc(fpr, tpr))

    def objective(self, trial: Trial) -> float:
        """Optuna objective function for hyperparameter optimization."""
        # Define hyperparameter search space
        param_trial = {
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
            "depth": trial.suggest_int("depth", 4, 8),
            "l2_leaf_reg": trial.suggest_float("l2_leaf_reg", 1, 50, log=True),
            "min_data_in_leaf": trial.suggest_int("min_data_in_leaf", 1, 100),
            "random_strength": trial.suggest_float("random_strength", 0, 10),
        }

        # Optional: Add boosting and bootstrap type optimization
        boosting_type = trial.suggest_categorical("boosting_type", ["Ordered", "Plain"])
        param_trial["boosting_type"] = boosting_type

        bootstrap_type = trial.suggest_categorical(
            "bootstrap_type", ["Bayesian", "Bernoulli", "MVS"]
        )
        param_trial["bootstrap_type"] = bootstrap_type

        # Bootstrap-specific parameters
        if bootstrap_type == "Bayesian":
            param_trial["bagging_temperature"] = trial.suggest_float(
                "bagging_temperature", 0, 10
            )
        elif bootstrap_type == "Bernoulli":
            param_trial["subsample"] = trial.suggest_float("subsample", 0.5, 1.0)

        # Merge parameters
        params = {**self.base_params, **param_trial}

        # Initialize model
        model = CatBoostClassifier(**params)

        # Setup pruning callback
        pruning_callback = CatBoostPruningCallback(trial, "AUC:use_weights=false")

        # Train model
        model.fit(
            self.train_pool,
            eval_set=self.val_pool,
            early_stopping_rounds=EARLY_STOPPING_ROUNDS,
            callbacks=[pruning_callback],
        )

        # Check if trial should be pruned
        pruning_callback.check_pruned()

        return self.get_score_rocauc(model)


def run_optimization(
    train_pool: Pool,
    val_pool: Pool,
    target_column: str,
    study_name: str = "catboost_auc_optimization",
    storage_file: str = "optuna-journal.log",
    n_trials: int = N_TRIALS,
) -> Dict[str, Any]:
    """
    Run hyperparameter optimization and return best parameters.

    Args:
        train_pool: Training data pool
        val_pool: Validation data pool
        target_column: Name of target column
        study_name: Name for the Optuna study
        storage_file: Path to journal storage file
        n_trials: Number of optimization trials

    Returns:
        Dictionary containing best parameters and score
    """
    # Initialize optimizer
    optimizer = CatBoostOptimizer(train_pool, val_pool, target_column, BASE_PARAMS)

    # Setup storage and study
    storage = JournalStorage(JournalFileStorage(storage_file))
    study = create_study(
        pruner=MedianPruner(n_warmup_steps=N_WARMUP_STEPS),
        direction="maximize",
        storage=storage,
        load_if_exists=True,
        study_name=study_name,
    )

    # Run optimization
    study.optimize(optimizer.objective, n_trials=n_trials, show_progress_bar=True)

    # Print results
    print(f"\n{'='*60}")
    print(f"Optimization Results")
    print(f"{'='*60}")
    print(f"Number of finished trials: {len(study.trials)}")
    print(
        f"Number of pruned trials: {len([t for t in study.trials if t.state.name == 'PRUNED'])}"
    )
    print(
        f"Number of complete trials: {len([t for t in study.trials if t.state.name == 'COMPLETE'])}"
    )

    return {
        "best_params": study.best_trial.params,
        "best_score": study.best_trial.value,
        "study": study,
    }