import warnings

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")


def calculate_feature_gini(df, target, exclude=None):
    """
    Calculate Gini coefficients for all numeric features in a dataframe.

    Parameters:
    -----------
    df : pandas.DataFrame
        Input dataframe
    target : str
        Target column name (binary)
    exclude : list, optional
        List of column names to exclude

    Returns:
    --------
    pandas.DataFrame
        DataFrame with features, their Gini coefficients, and interpretation
    """
    if exclude is None:
        exclude = []

    # Exclude target and specified columns
    exclude = exclude + [target]
    features = [col for col in df.columns if col not in exclude]

    results = []
    for feature in features:
        # Skip non-numeric features
        if not np.issubdtype(df[feature].dtype, np.number):
            continue

        # Handle missing values
        data = df[[feature, target]].dropna()

        try:
            # Skip constant features
            if data[feature].nunique() <= 1:
                gini = 0
                direction = "N/A"
            else:
                # Calculate AUC and Gini
                auc = roc_auc_score(data[target], data[feature])

                # Determine direction of relationship
                if auc < 0.5:
                    auc = roc_auc_score(data[target], -data[feature])
                    gini = 2 * auc - 1
                    direction = "Negative"
                else:
                    gini = 2 * auc - 1
                    direction = "Positive"
        except:
            # In case of errors (e.g., all targets are the same class)
            gini = np.nan
            direction = "Error"

        # Interpret Gini value
        if np.isnan(gini):
            interpretation = "Cannot be calculated"
        elif gini < 0.02:
            interpretation = "No predictive power"
        elif gini < 0.1:
            interpretation = "Weak predictive power"
        elif gini < 0.2:
            interpretation = "Moderate predictive power"
        elif gini < 0.3:
            interpretation = "Good predictive power"
        elif gini < 0.4:
            interpretation = "Very good predictive power"
        else:
            interpretation = "Excellent predictive power"

        results.append(
            {
                "Feature": feature,
                "Gini": gini,
                "Direction": direction,
                "Interpretation": interpretation,
            }
        )

    # Create and sort results dataframe
    results_df = pd.DataFrame(results)
    return results_df.sort_values("Gini", ascending=False).reset_index(drop=True)


def calculate_feature_prauc(df, target, exclude=None):
    """
    Calculate PR AUC scores for all numeric features in a dataframe.

    Parameters:
    -----------
    df : pandas.DataFrame
        Input dataframe
    target : str
        Target column name (binary)
    exclude : list, optional
        List of column names to exclude

    Returns:
    --------
    pandas.DataFrame
        DataFrame with features, their PR AUC scores, and interpretation
    """
    if exclude is None:
        exclude = []

    # Exclude target and specified columns
    exclude = exclude + [target]
    features = [col for col in df.columns if col not in exclude]

    # Calculate baseline PR AUC (random classifier performance)
    baseline_pr_auc = df[target].mean()

    results = []
    for feature in features:
        # Skip non-numeric features
        if not np.issubdtype(df[feature].dtype, np.number):
            continue

        # Handle missing values
        data = df[[feature, target]].dropna()

        try:
            # Skip constant features
            if data[feature].nunique() <= 1:
                pr_auc = baseline_pr_auc
                direction = "N/A"
                lift = 0
            else:
                # Calculate PR AUC for positive direction
                pr_auc_pos = average_precision_score(data[target], data[feature])

                # Calculate PR AUC for negative direction (invert feature)
                feature_inverted = -data[
                    feature
                ]  # or data[feature].max() - data[feature]
                pr_auc_neg = average_precision_score(data[target], feature_inverted)

                # Choose the better direction
                if pr_auc_pos >= pr_auc_neg:
                    pr_auc = pr_auc_pos
                    direction = "Positive"
                else:
                    pr_auc = pr_auc_neg
                    direction = "Negative"

                # Calculate lift over baseline
                lift = (pr_auc - baseline_pr_auc) / baseline_pr_auc * 100

        except Exception as e:
            # In case of errors (e.g., all targets are the same class)
            pr_auc = np.nan
            direction = "Error"
            lift = np.nan

        # Interpret PR AUC value (relative to baseline)
        if np.isnan(pr_auc):
            interpretation = "Cannot be calculated"
        elif pr_auc <= baseline_pr_auc * 1.05:  # Within 5% of baseline
            interpretation = "No predictive power"
        elif pr_auc <= baseline_pr_auc * 1.25:  # 25% improvement over baseline
            interpretation = "Weak predictive power"
        elif pr_auc <= baseline_pr_auc * 1.5:  # 50% improvement over baseline
            interpretation = "Moderate predictive power"
        elif pr_auc <= baseline_pr_auc * 2.0:  # 100% improvement over baseline
            interpretation = "Good predictive power"
        elif pr_auc <= baseline_pr_auc * 3.0:  # 200% improvement over baseline
            interpretation = "Very good predictive power"
        else:
            interpretation = "Excellent predictive power"

        results.append(
            {
                "Feature": feature,
                "PR_AUC": pr_auc,
                "Baseline_PR_AUC": baseline_pr_auc,
                "Lift_%": lift,
                "Direction": direction,
                "Interpretation": interpretation,
            }
        )

    # Create and sort results dataframe
    results_df = pd.DataFrame(results)
    return results_df.sort_values("PR_AUC", ascending=False).reset_index(drop=True)


def calculate_feature_predictive_metrics(df, target, exclude=None):
    """
    Combine the outputs of both calculate_feature_gini and calculate_feature_prauc functions.

    Parameters:
    -----------
    df : pandas.DataFrame
        Input dataframe
    target : str
        Target column name (binary)
    exclude : list, optional
        List of column names to exclude

    Returns:
    --------
    pandas.DataFrame
        DataFrame with features, Gini coefficients, PR AUC scores, and interpretations
    """
    # Get individual metric results
    gini_results = calculate_feature_gini(df, target, exclude)
    prauc_results = calculate_feature_prauc(df, target, exclude)

    # Merge the results on the Feature column
    combined_results = pd.merge(
        gini_results, prauc_results, on="Feature", suffixes=("_Gini", "_PRAUC")
    )
    return combined_results