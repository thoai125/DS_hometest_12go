import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
from scipy.stats import chi2_contingency
from typing import Optional, List, Union, Tuple

def plot_boolean_conversion_rate(df, feature_name, target_col="click"):
    """
    Specialized function for boolean features to avoid indexing errors
    """
    # Remove any missing values and ensure boolean type
    df_clean = df.dropna(subset=[feature_name, target_col]).copy()

    # Convert boolean to string with meaningful labels
    df_clean[f"{feature_name}_label"] = df_clean[feature_name].map(
        {True: "True", False: "False"}
    )

    # Calculate conversion stats
    conversion_stats = (
        df_clean.groupby(f"{feature_name}_label")[target_col]
        .agg(["count", "sum", "mean"])
        .reset_index()
    )

    conversion_stats.columns = [
        "category",
        "total_count",
        "conversions",
        "conversion_rate",
    ]

    # Ensure we have data for both True and False
    if len(conversion_stats) == 0:
        print("No data available for analysis")
        return None

    # Sort by the category to ensure consistent ordering
    conversion_stats = conversion_stats.sort_values("category")

    # Create the plot
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Add bar chart for counts
    fig.add_trace(
        go.Bar(
            x=conversion_stats["category"],
            y=conversion_stats["total_count"],
            name="Total Count",
            marker_color="lightblue",
            text=[f"{count:,}" for count in conversion_stats["total_count"]],
            textposition="outside",
        ),
        secondary_y=False,
    )

    # Add line chart for conversion rate
    fig.add_trace(
        go.Scatter(
            x=conversion_stats["category"],
            y=conversion_stats["conversion_rate"],
            mode="lines+markers",
            name="Booking Rate",
            line=dict(color="red", width=3),
            marker=dict(size=10, color="red"),
            text=[f"{rate:.1%}" for rate in conversion_stats["conversion_rate"]],
            textposition="top center",
        ),
        secondary_y=True,
    )

    # Update axes
    fig.update_xaxes(title_text=f"{feature_name}")
    fig.update_yaxes(title_text="Count", secondary_y=False)
    fig.update_yaxes(title_text="Booking Rate", tickformat=".1%", secondary_y=True)

    # Update layout
    fig.update_layout(
        title=f"Count and Booking Rate by {feature_name}",
        height=500,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )

    fig.show()
    return conversion_stats
def plot_categorical_conversion_rate_fixed(
    df, feature_name, target_col="click", top_n=15
):
    # Remove any missing values first
    df_clean = df.dropna(subset=[feature_name]).copy()

    # Handle categorical dtype - convert to string to preserve order and handle properly
    if pd.api.types.is_categorical_dtype(df_clean[feature_name]):
        # Get all categories (including unused ones) to maintain proper ordering
        all_categories = df_clean[feature_name].cat.categories.tolist()

        # Convert to string while preserving categorical order
        df_clean[feature_name] = df_clean[feature_name].astype(str)

        # Get value counts maintaining categorical order
        value_counts = df_clean[feature_name].value_counts()

        # If we want to respect original categorical order, reindex by categories present in data
        present_categories = [
            cat for cat in all_categories if str(cat) in value_counts.index
        ]
        if present_categories:
            value_counts = value_counts.reindex(
                [str(cat) for cat in present_categories], fill_value=0
            )
    else:
        # Handle non-categorical data as before
        value_counts = df_clean[feature_name].value_counts()

    # Get top N categories by frequency
    top_categories = value_counts.head(top_n).index.tolist()

    # Filter data to top categories only
    filtered_df = df_clean[df_clean[feature_name].isin(top_categories)]

    # Calculate conversion rate for each category
    conversion_stats = (
        filtered_df.groupby(feature_name)[target_col]
        .agg(["count", "sum", "mean"])
        .reset_index()
    )

    conversion_stats.columns = [
        feature_name,
        "total_count",
        "conversions",
        "conversion_rate",
    ]

    # Sort by total count (or preserve categorical order if needed)
    conversion_stats = conversion_stats.sort_values("total_count", ascending=False)

    # Create the plot with secondary y-axis
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Add bar chart for counts (primary y-axis)
    fig.add_trace(
        go.Bar(
            x=conversion_stats[feature_name].astype(str),
            y=conversion_stats["total_count"],
            name="Total Count",
            marker_color="lightblue",
            text=[f"{count:,}" for count in conversion_stats["total_count"]],
            textposition="outside",
        ),
        secondary_y=False,
    )

    # Add line chart for conversion rate (secondary y-axis)
    fig.add_trace(
        go.Scatter(
            x=conversion_stats[feature_name].astype(str),
            y=conversion_stats["conversion_rate"],
            mode="lines+markers",
            name="Booking Rate",
            line=dict(color="red", width=3),
            marker=dict(size=8, color="red"),
            text=[f"{rate:.1%}" for rate in conversion_stats["conversion_rate"]],
            textposition="top center",
        ),
        secondary_y=True,
    )

    # Update x-axis
    fig.update_xaxes(title_text=f"{feature_name}")

    # Update y-axes
    fig.update_yaxes(title_text="Count", secondary_y=False)
    fig.update_yaxes(title_text="Booking Rate", tickformat=".1%", secondary_y=True)

    # Update layout
    fig.update_layout(
        title=f"Count and Booking Rate by {feature_name} (Top {top_n} Categories)",
        height=500,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )

    fig.show()

    return conversion_stats


def plot_all_categorical_features(
    df, categorical_features, target_col="click", top_n=15
):
    """
    Plot each feature individually using the original fixed function
    """
    all_stats = {}

    for feature in categorical_features:
        print(f"\n{'='*50}")
        print(f"PLOTTING: {feature}")
        print(f"{'='*50}")

        stats = plot_categorical_conversion_rate_fixed(df, feature, target_col, top_n)
        all_stats[feature] = stats

        print(f"\nCompleted {feature}")

    return all_stats
def cramers_v_matrix_fast(
    df: pd.DataFrame,
    categorical_columns: Optional[List[str]] = None,
    figsize: Tuple[int, int] = (10, 8),
    annot: bool = True,
    cmap: str = "RdYlBu_r",
    return_matrix: bool = True,
    title: str = "Cramér's V Correlation Heatmap",
    save_path: Optional[str] = None,
    min_categories: int = 2,
    max_categories: int = 50,  # Lower by default for speed!
    plot: bool = True,  # Option to skip plotting for speed
    verbose: bool = False,  # Print progress if True
) -> Optional[pd.DataFrame]:

    # Helper function for Cramér's V
    def cramers_v(confusion_matrix: pd.DataFrame) -> float:
        if confusion_matrix.empty or confusion_matrix.sum().sum() == 0:
            return 0.0
        try:
            chi2 = chi2_contingency(confusion_matrix)[0]
            n = confusion_matrix.sum().sum()
            if n <= 1:
                return 0.0
            phi2 = chi2 / n
            r, k = confusion_matrix.shape
            phi2corr = max(0, phi2 - ((k - 1) * (r - 1)) / (n - 1))
            rcorr = r - ((r - 1) ** 2) / (n - 1)
            kcorr = k - ((k - 1) ** 2) / (n - 1)
            denominator = min((kcorr - 1), (rcorr - 1))
            if denominator <= 0:
                return 0.0
            return np.sqrt(phi2corr / denominator)
        except (ValueError, ZeroDivisionError):
            return 0.0

    if df.empty:
        raise ValueError("Input DataFrame is empty")

    # Auto-detect categorical columns if not provided
    if categorical_columns is None:
        potential_cols = df.select_dtypes(include=["object", "category"]).columns
        categorical_columns = [
            col
            for col in potential_cols
            if min_categories <= df[col].nunique() <= max_categories
        ]
        # Also add low-cardinality numerics
        for col in df.select_dtypes(include=[np.number]).columns:
            if min_categories <= df[col].nunique() <= max_categories:
                categorical_columns.append(col)

    # Filter to only columns present
    categorical_columns = [col for col in categorical_columns if col in df.columns]
    if len(categorical_columns) < 2:
        raise ValueError("At least 2 categorical columns are required")

    n = len(categorical_columns)
    result = np.ones((n, n))
    # Only compute for lower triangle
    for i in range(n):
        for j in range(i):
            col1, col2 = categorical_columns[i], categorical_columns[j]
            confusion_matrix = pd.crosstab(df[col1], df[col2])
            val = cramers_v(confusion_matrix)
            result[i, j] = result[j, i] = val
            if verbose:
                print(f"Cramér's V for {col1} vs {col2}: {val:.3f}")

    result_df = pd.DataFrame(
        result, index=categorical_columns, columns=categorical_columns
    )

    if plot:
        plt.figure(figsize=figsize)
        mask = np.triu(np.ones_like(result_df, dtype=bool), k=1)
        sns.heatmap(
            result_df,
            annot=annot,
            cmap=cmap,
            vmin=0,
            vmax=1,
            square=True,
            mask=mask,
            cbar_kws={"label": "Cramér's V"},
            fmt=".3f" if annot else None,
            linewidths=0.5,
        )
        plt.title(title, fontsize=14, fontweight="bold")
        plt.xlabel("Variables", fontsize=12)
        plt.ylabel("Variables", fontsize=12)
        plt.xticks(rotation=45, ha="right")
        plt.yticks(rotation=0)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches="tight")
            print(f"Figure saved to: {save_path}")
        plt.show()

    return result_df if return_matrix else None
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd


def plot_feature_distributions(
    df: pd.DataFrame,
    feat_num: list,
    n_cols: int = 3,
    nbins: int = 30,
    height_per_row: int = 350,
    width: int = 1800,
    title: str = "Distribution of Numerical Features",
    show_legend: bool = False,
):
    """
    Create a grid of histograms showing the distribution of numerical features.

    Parameters:
    -----------
    df : pd.DataFrame
        Input dataframe
    feat_num : list
        List of numerical feature column names to plot
    n_cols : int, default=3
        Number of columns in the subplot grid
    nbins : int, default=30
        Number of bins for each histogram
    height_per_row : int, default=350
        Height in pixels per row
    width : int, default=1800
        Total width of the figure
    title : str
        Main title for the plot
    show_legend : bool, default=False
        Whether to show the legend

    Returns:
    --------
    plotly.graph_objects.Figure
        The complete figure object
    """

    # Calculate layout
    n_features = len(feat_num)
    n_rows = int(np.ceil(n_features / n_cols))

    # Create subplots with custom styling
    fig = make_subplots(
        rows=n_rows,
        cols=n_cols,
        subplot_titles=[f"<b>{col}</b>" for col in feat_num],
        vertical_spacing=0.10,
        horizontal_spacing=0.08,
    )

    # Add histogram for each feature
    for idx, col in enumerate(feat_num):
        row = idx // n_cols + 1
        col_pos = idx % n_cols + 1

        # Get data and remove NaN
        data = df[col].dropna()

        fig.add_trace(
            go.Histogram(
                x=data,
                name=col,
                nbinsx=nbins,
                marker=dict(
                    color="steelblue",
                    line=dict(color="black", width=0.5),
                    opacity=0.8,
                ),
                hovertemplate=(
                    "<b>%{x}</b><br>" + "Count: %{y}<br>" + "<extra></extra>"
                ),
                showlegend=False,
            ),
            row=row,
            col=col_pos,
        )

        # Update axes
        fig.update_xaxes(
            title_text="Value",
            title_font=dict(size=11),
            showgrid=True,
            gridwidth=1,
            gridcolor="lightgray",
            row=row,
            col=col_pos,
        )

        fig.update_yaxes(
            title_text="Count",
            title_font=dict(size=11),
            showgrid=True,
            gridwidth=1,
            gridcolor="lightgray",
            row=row,
            col=col_pos,
        )

    # Update overall layout
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b>",
            font=dict(size=24, family="Arial Black"),
            x=0.5,
            xanchor="center",
            y=0.98,
            yanchor="top",
        ),
        height=height_per_row * n_rows,
        width=width,
        showlegend=show_legend,
        template="plotly_white",
        margin=dict(t=100, b=50, l=50, r=50),
    )

    # Style subplot titles
    for annotation in fig["layout"]["annotations"]:
        annotation["font"] = dict(size=13, family="Arial")

    return fig


def plot_feature_analysis(
    df: pd.DataFrame,
    feat_num: list,
    target_col: str = "default",
    target_values: tuple = (0, 1),
    target_labels: tuple = ("No Default", "Default"),
    colors: tuple = ("steelblue", "coral"),
    nbins: int = 30,
    height_per_row: int = 700,
    width: int = 1200,
    title: str = "Feature Analysis: Distribution + Box Plot by Default Status",
):
    """
    Create distribution and box plot analysis for numerical features split by a binary target variable.

    Parameters:
    -----------
    df : pd.DataFrame
        Input dataframe
    feat_num : list
        List of numerical feature column names to analyze
    target_col : str, default="default"
        Name of the binary target column
    target_values : tuple, default=(0, 1)
        Values representing the two classes (negative, positive)
    target_labels : tuple, default=("No Default", "Default")
        Labels for the two classes
    colors : tuple, default=("steelblue", "coral")
        Colors for the two classes
    nbins : int, default=30
        Number of bins for histograms
    height_per_row : int, default=700
        Height in pixels per feature row
    width : int, default=1200
        Total width of the figure
    title : str
        Main title for the plot

    Returns:
    --------
    plotly.graph_objects.Figure
        The complete figure object
    """

    # Calculate layout - 2 plots per feature (histogram + boxplot)
    n_features = len(feat_num)
    n_cols = 2  # 2 columns: histogram and boxplot
    n_rows = n_features

    # Create subplot titles
    subplot_titles = []
    for col in feat_num:
        subplot_titles.append(f"<b>{col} - Distribution</b>")
        subplot_titles.append(f"<b>{col} - Box Plot</b>")

    # Create subplots
    fig = make_subplots(
        rows=n_rows,
        cols=n_cols,
        subplot_titles=subplot_titles,
        vertical_spacing=0.03,
        horizontal_spacing=0.12,
        column_widths=[0.7, 0.3],  # Histogram wider than boxplot
    )

    # Add plots for each feature
    for idx, col in enumerate(feat_num):
        row = idx + 1

        # Split data
        data_class0 = df[df[target_col] == target_values[0]][col].dropna()
        data_class1 = df[df[target_col] == target_values[1]][col].dropna()

        # Statistics (optional, can be used for annotations)
        mean_0 = data_class0.mean()
        mean_1 = data_class1.mean()
        median_0 = data_class0.median()
        median_1 = data_class1.median()

        # ===== HISTOGRAM (Column 1) =====
        # Class 0 histogram
        fig.add_trace(
            go.Histogram(
                x=data_class0,
                name=target_labels[0],
                nbinsx=nbins,
                marker=dict(color=colors[0], opacity=0.6, line=dict(width=0.5)),
                legendgroup="class0",
                showlegend=(idx == 0),
                histnorm="probability density",
            ),
            row=row,
            col=1,
        )

        # Class 1 histogram
        fig.add_trace(
            go.Histogram(
                x=data_class1,
                name=target_labels[1],
                nbinsx=nbins,
                marker=dict(color=colors[1], opacity=0.6, line=dict(width=0.5)),
                legendgroup="class1",
                showlegend=(idx == 0),
                histnorm="probability density",
            ),
            row=row,
            col=1,
        )

        # ===== BOX PLOT (Column 2) =====
        # Class 0 box
        fig.add_trace(
            go.Box(
                y=data_class0,
                name=target_labels[0],
                marker=dict(color=colors[0]),
                boxmean="sd",
                legendgroup="class0",
                showlegend=False,
            ),
            row=row,
            col=2,
        )

        # Class 1 box
        fig.add_trace(
            go.Box(
                y=data_class1,
                name=target_labels[1],
                marker=dict(color=colors[1]),
                boxmean="sd",
                legendgroup="class1",
                showlegend=False,
            ),
            row=row,
            col=2,
        )

        # Update axes for histogram
        fig.update_xaxes(
            title_text="Value", showgrid=True, gridcolor="lightgray", row=row, col=1
        )
        fig.update_yaxes(
            title_text="Density", showgrid=True, gridcolor="lightgray", row=row, col=1
        )

        # Update axes for boxplot
        fig.update_xaxes(showticklabels=True, row=row, col=2)
        fig.update_yaxes(
            title_text="Value", showgrid=True, gridcolor="lightgray", row=row, col=2
        )

    # Update layout
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b>",
            font=dict(size=24),
            x=0.5,
            xanchor="center",
        ),
        height=height_per_row * n_rows,
        width=width,
        barmode="overlay",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.01,
            xanchor="right",
            x=1,
            font=dict(size=14),
        ),
        template="plotly_white",
        hovermode="closest",
    )

    # Update subplot titles
    for annotation in fig["layout"]["annotations"]:
        annotation["font"] = dict(size=11)

    return fig

def plot_correlation_matrix(
    df: pd.DataFrame,
    feat_num: list,
    method: str = "pearson",
    width: int = 1000,
    height: int = 900,
    title: str = "Correlation Matrix of Numerical Features",
    colorscale: str = "RdBu",
    show_values: bool = True,
    decimals: int = 2,
):
    """
    Calculate and plot correlation matrix for numerical features.

    Parameters:
    -----------
    df : pd.DataFrame
        Input dataframe
    feat_num : list
        List of numerical feature column names
    method : str, default='pearson'
        Correlation method: 'pearson', 'spearman', or 'kendall'
    width : int, default=1000
        Width of the figure
    height : int, default=900
        Height of the figure
    title : str
        Main title for the plot
    colorscale : str, default='RdBu'
        Plotly colorscale name (e.g., 'RdBu', 'Viridis', 'Blues')
    show_values : bool, default=True
        Whether to display correlation values on the heatmap
    decimals : int, default=2
        Number of decimal places for correlation values

    Returns:
    --------
    tuple: (plotly.graph_objects.Figure, pd.DataFrame)
        The figure object and the correlation matrix dataframe
    """

    # Calculate correlation matrix
    corr_matrix = df[feat_num].corr(method=method)

    # Round for display
    corr_display = corr_matrix.round(decimals)

    # Create text annotations if show_values is True
    if show_values:
        text = [[f"{val:.{decimals}f}" for val in row] for row in corr_matrix.values]
    else:
        text = None

    # Create heatmap
    fig = go.Figure(
        data=go.Heatmap(
            z=corr_matrix.values,
            x=feat_num,
            y=feat_num,
            colorscale=colorscale,
            zmid=0,  # Center colorscale at 0
            zmin=-1,
            zmax=1,
            text=text,
            texttemplate="%{text}" if show_values else None,
            textfont={"size": 10},
            colorbar=dict(
                title=f"{method.capitalize()}<br>Correlation",
                titleside="right",
                tickmode="linear",
                tick0=-1,
                dtick=0.2,
            ),
            hovertemplate=(
                "<b>%{x}</b> vs <b>%{y}</b><br>"
                + "Correlation: %{z:.3f}<br>"
                + "<extra></extra>"
            ),
        )
    )

    # Update layout
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b>",
            font=dict(size=20, family="Arial Black"),
            x=0.5,
            xanchor="center",
        ),
        width=width,
        height=height,
        xaxis=dict(title="", tickangle=-45, side="bottom", tickfont=dict(size=11)),
        yaxis=dict(
            title="",
            tickfont=dict(size=11),
            autorange="reversed",  # To have the same order as the dataframe
        ),
        template="plotly_white",
        margin=dict(t=100, b=150, l=150, r=150),
    )

    return fig, corr_matrix


def get_high_correlations(
    corr_matrix: pd.DataFrame, threshold: float = 0.7, exclude_self: bool = True
):
    """
    Extract pairs of features with high correlation.

    Parameters:
    -----------
    corr_matrix : pd.DataFrame
        Correlation matrix
    threshold : float, default=0.7
        Absolute correlation threshold
    exclude_self : bool, default=True
        Whether to exclude self-correlations (diagonal)

    Returns:
    --------
    pd.DataFrame
        DataFrame with columns: Feature1, Feature2, Correlation
    """

    # Get upper triangle to avoid duplicates
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool), k=1 if exclude_self else 0)

    # Find high correlations
    high_corr = []
    for i in range(len(corr_matrix)):
        for j in range(len(corr_matrix)):
            if mask[i, j] and abs(corr_matrix.iloc[i, j]) >= threshold:
                high_corr.append(
                    {
                        "Feature1": corr_matrix.index[i],
                        "Feature2": corr_matrix.columns[j],
                        "Correlation": corr_matrix.iloc[i, j],
                    }
                )

    # Create DataFrame and sort by absolute correlation
    high_corr_df = pd.DataFrame(high_corr)
    if not high_corr_df.empty:
        high_corr_df = high_corr_df.sort_values(
            "Correlation", key=abs, ascending=False
        ).reset_index(drop=True)

    return high_corr_df
