import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score

def recursive_feature_elimination(
    train_X, train_y, val_X, val_y, test_X, test_y, max_iterations=5
):
    """
    Perform recursive feature elimination based on validation AUC

    Returns:
        tuple: (features_dropped, elimination_history)
    """
    print("Starting Recursive Feature Elimination...")
    print(f"Initial features: {train_X.shape[1]}")

    # Initialize tracking variables
    feat_drop = []
    iteration_results = []

    for current_iteration in range(1, max_iterations + 1):
        print(f"\n=== Iteration {current_iteration} ===")
        print(f"Features dropped so far: {len(feat_drop)}")

        # Get remaining features
        features_to_analyze = [col for col in train_X.columns if col not in feat_drop]

        if len(features_to_analyze) <= 1:
            print("Only one feature remaining. Stopping iterations.")
            break

        print(f"Testing removal from {len(features_to_analyze)} remaining features...")

        # Test removal of each feature
        results = []
        for i, feature in enumerate(features_to_analyze):
            print(
                f"  Testing removal of feature ({i+1}/{len(features_to_analyze)}): {feature}"
            )

            # Create feature subset without current feature
            features_subset = [f for f in features_to_analyze if f != feature]

            try:
                # Train model without this feature
                model = LogisticRegression(
                    penalty="l2", C=0.3, max_iter=1000, random_state=42
                )
                model.fit(train_X[features_subset], train_y)

                # Get predictions for all datasets
                pred_train = model.predict_proba(train_X[features_subset])[:, 1]
                pred_val = model.predict_proba(val_X[features_subset])[:, 1]
                pred_test = model.predict_proba(test_X[features_subset])[:, 1]

                # Calculate metrics
                auc_train = roc_auc_score(train_y, pred_train)
                auc_val = roc_auc_score(val_y, pred_val)
                auc_test = roc_auc_score(test_y, pred_test)

                results.append(
                    {
                        "feature_removed": feature,
                        "num_features": len(features_subset),
                        "AUC_train": auc_train,
                        "AUC_val": auc_val,
                        "AUC_test": auc_test,
                    }
                )

                print(
                    f"    Train AUC: {auc_train:.4f}, Val AUC: {auc_val:.4f}, Test AUC: {auc_test:.4f}"
                )

            except Exception as e:
                print(f"    Error: {str(e)}")
                continue

        if not results:
            print("No valid results. Stopping elimination.")
            break

        # Convert to DataFrame and find best feature to remove
        results_df = pd.DataFrame(results)

        # Filter for models where validation AUC < training AUC (avoid overfitting)
        valid_results = results_df[results_df["AUC_val"] <= results_df["AUC_train"]]

        if valid_results.empty:
            valid_results = (
                results_df  # Fall back to all results if none satisfy condition
            )

        # Sort by validation AUC (descending) - we want highest validation performance
        results_sorted = valid_results.sort_values("AUC_val", ascending=False)

        # Select feature to drop
        best_result = results_sorted.iloc[0]
        feature_to_drop = best_result["feature_removed"]

        # Add to dropped features list
        feat_drop.append(feature_to_drop)

        # Record iteration results
        iteration_results.append(
            {
                "iteration": current_iteration,
                "features_remaining": len(features_to_analyze) - 1,
                "feature_dropped": feature_to_drop,
                "auc_train": best_result["AUC_train"],
                "auc_val": best_result["AUC_val"],
                "auc_test": best_result["AUC_test"],
            }
        )

        print(f"\nDropping feature: {feature_to_drop}")
        print(
            f"Train AUC: {best_result['AUC_train']:.4f}, Val AUC: {best_result['AUC_val']:.4f}, Test AUC: {best_result['AUC_test']:.4f}"
        )
        print(f"Features dropped so far ({len(feat_drop)}): {feat_drop}")

    print(f"\n=== Feature Elimination Complete ===")
    print(f"Total features dropped: {len(feat_drop)}")
    print(f"Features remaining: {train_X.shape[1] - len(feat_drop)}")

    return feat_drop, iteration_results