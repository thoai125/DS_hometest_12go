import numpy as np
import pandas as pd
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    precision_score,
    recall_score,
    accuracy_score,
    f1_score,
    confusion_matrix,
    fbeta_score
)
import matplotlib.pyplot as plt
import seaborn as sns


def evaluate_model_performance(
    y_val,
    y_test,
    val_pred_lr,
    test_pred_lr,
    threshold_lr,
    val_pred_cb,
    test_pred_cb,
    threshold_cb,
    model_names=["Logistic Regression", "CatBoost"],
):
    """
    Evaluate and compare performance of two models on validation and test sets.

    Parameters:
    -----------
    y_val, y_test : array-like
        True labels for validation and test sets
    val_pred_lr, test_pred_lr : array-like
        Predicted probabilities from logistic regression model
    threshold_lr : float
        Decision threshold for logistic regression
    val_pred_cb, test_pred_cb : array-like
        Predicted probabilities from CatBoost model
    threshold_cb : float
        Decision threshold for CatBoost
    model_names : list
        Names of the models for display

    Returns:
    --------
    dict : Performance metrics for both models and datasets
    """

    def calculate_metrics(y_true, y_pred_proba, threshold):
        """Calculate all metrics for a single model"""
        y_pred_binary = (y_pred_proba >= threshold).astype(int)

        metrics = {
            "ROC_AUC": roc_auc_score(y_true, y_pred_proba),
            "PR_AUC": average_precision_score(y_true, y_pred_proba),
            "Precision": precision_score(y_true, y_pred_binary, zero_division=0),
            "Recall": recall_score(y_true, y_pred_binary, zero_division=0),
           # "F1_Score": f1_score(y_true, y_pred_binary, zero_division=0),
            "F2_Score": fbeta_score(y_true, y_pred_binary, beta=2, zero_division=0),
            "Accuracy": accuracy_score(y_true, y_pred_binary),
            "Threshold": threshold,
            "Confusion_Matrix": confusion_matrix(y_true, y_pred_binary),
        }
        return metrics

    # Calculate metrics for all combinations
    results = {
        f"{model_names[0]}_Validation": calculate_metrics(
            y_val, val_pred_lr, threshold_lr
        ),
        f"{model_names[0]}_Test": calculate_metrics(y_test, test_pred_lr, threshold_lr),
        f"{model_names[1]}_Validation": calculate_metrics(
            y_val, val_pred_cb, threshold_cb
        ),
        f"{model_names[1]}_Test": calculate_metrics(y_test, test_pred_cb, threshold_cb),
    }

    return results


def display_performance_table(results):
    """Display results in a formatted table"""
    # Create a copy without confusion matrix for table display
    results_for_table = {}
    for key, metrics in results.items():
        results_for_table[key] = {
            k: v for k, v in metrics.items() if k != "Confusion_Matrix"
        }

    df = pd.DataFrame(results_for_table).T
    df = df.round(4)

    print("=" * 90)
    print("MODEL PERFORMANCE COMPARISON")
    print("=" * 90)
    print(df.to_string())
    print("=" * 90)

    return df


def plot_confusion_matrices(results, model_names=["Logistic Regression", "CatBoost"]):
    """Plot confusion matrices for both models on validation and test sets"""

    fig, axes = plt.subplots(2, 4, figsize=(20, 10))
    fig.suptitle("Confusion Matrices Comparison", fontsize=16, fontweight="bold")

    # Define positions for each subplot
    positions = [
        (0, 0, f"{model_names[0]}_Validation"),
        (0, 1, f"{model_names[0]}_Test"),
        (0, 2, f"{model_names[1]}_Validation"),
        (0, 3, f"{model_names[1]}_Test"),
    ]

    for row, col, key in positions:
        ax = axes[row, col]
        cm = results[key]["Confusion_Matrix"]
        threshold = results[key]["Threshold"]

        # Create heatmap
        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            ax=ax,
            xticklabels=["Reject (0)", "Accept (1)"],
            yticklabels=["Actual Reject (0)", "Actual Accept (1)"],
        )

        # Extract model name and dataset
        model_name = (
            key.split("_")[0] + " " + key.split("_")[1]
            if "Logistic" in key
            else key.split("_")[0]
        )
        dataset = key.split("_")[-1]

        ax.set_title(f"{model_name}\n{dataset} Set (threshold={threshold:.3f})")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")

        # Add performance metrics as text
        tn, fp, fn, tp = cm.ravel()
        total = tn + fp + fn + tp

        metrics_text = f"TN: {tn} | FP: {fp}\nFN: {fn} | TP: {tp}\nTotal: {total}"
        ax.text(
            1.05,
            0.5,
            metrics_text,
            transform=ax.transAxes,
            verticalalignment="center",
            fontsize=10,
            bbox=dict(boxstyle="round", facecolor="lightgray", alpha=0.8),
        )

    # Remove empty subplots in second row
    for col in range(4):
        fig.delaxes(axes[1, col])

    plt.tight_layout()
    plt.show()


def plot_performance_comparison(results, save_path=None):
    """Create visualization comparing model performances"""
    df = pd.DataFrame(
        {
            k: {
                metric: v
                for metric, v in metrics.items()
                if metric != "Confusion_Matrix"
            }
            for k, metrics in results.items()
        }
    ).T

    # Separate metrics (exclude threshold)
    metrics_to_plot = [
        "ROC_AUC",
        "PR_AUC",
        "Precision",
        "Recall",
        "F2_Score",
        "Accuracy",
    ]

    # Create subplots
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.suptitle(
        "Model Performance Comparison: Validation vs Test",
        fontsize=16,
        fontweight="bold",
    )

    # Plot each metric
    for idx, metric in enumerate(metrics_to_plot):
        row, col = idx // 3, idx % 3
        ax = axes[row, col]

        # Extract data for plotting
        lr_val = df.loc[df.index.str.contains("Logistic.*Validation"), metric].values[0]
        lr_test = df.loc[df.index.str.contains("Logistic.*Test"), metric].values[0]
        cb_val = df.loc[df.index.str.contains("CatBoost.*Validation"), metric].values[0]
        cb_test = df.loc[df.index.str.contains("CatBoost.*Test"), metric].values[0]

        # Bar plot
        x = np.arange(2)
        width = 0.35

        bars1 = ax.bar(
            x - width / 2,
            [lr_val, lr_test],
            width,
            label="Logistic Regression",
            alpha=0.8,
        )
        bars2 = ax.bar(
            x + width / 2, [cb_val, cb_test], width, label="CatBoost", alpha=0.8
        )

        ax.set_ylabel(metric)
        ax.set_title(f"{metric} Comparison")
        ax.set_xticks(x)
        ax.set_xticklabels(["Validation", "Test"])
        ax.legend()
        ax.grid(True, alpha=0.3)

        # Add value labels on bars
        for bars in [bars1, bars2]:
            for bar in bars:
                height = bar.get_height()
                ax.annotate(
                    f"{height:.3f}",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=9,
                )

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")

    plt.show()


def analyze_confusion_matrices(
    results, model_names=["Logistic Regression", "CatBoost"]
):
    """Analyze confusion matrices and provide insights"""
    print("\n" + "=" * 80)
    print("CONFUSION MATRIX ANALYSIS")
    print("=" * 80)

    for model in model_names:
        print(f"\n{model}:")
        print("-" * 50)

        for dataset in ["Validation", "Test"]:
            key = f"{model}_{dataset}"
            cm = results[key]["Confusion_Matrix"]
            tn, fp, fn, tp = cm.ravel()
            total = tn + fp + fn + tp

            print(f"\n  {dataset} Set:")
            print(
                f"    True Negatives (Correct Rejects):  {tn:>6} ({tn/total*100:.1f}%)"
            )
            print(
                f"    False Positives (Wrong Accepts):   {fp:>6} ({fp/total*100:.1f}%)"
            )
            print(
                f"    False Negatives (Wrong Rejects):  {fn:>6} ({fn/total*100:.1f}%)"
            )
            print(
                f"    True Positives (Correct Accepts):  {tp:>6} ({tp/total*100:.1f}%)"
            )
            print(f"    Total Predictions:                 {total:>6}")

            # Business impact analysis
            if fp > 0 or fn > 0:
                print(f"    💡 Business Impact:")
                if fp > 0:
                    print(f"       - {fp} cases wrongly accepted (potential risk)")
                if fn > 0:
                    print(
                        f"       - {fn} cases wrongly rejected (potential lost opportunity)"
                    )


def analyze_overfitting(results):
    """Analyze potential overfitting by comparing val vs test performance"""
    print("\n" + "=" * 70)
    print("OVERFITTING ANALYSIS")
    print("=" * 70)

    models = ["Logistic Regression", "CatBoost"]
    metrics = ["ROC_AUC", "PR_AUC", "Precision", "Recall", "F2_Score", "Accuracy"]

    for model in models:
        print(f"\n{model}:")
        print("-" * 35)

        val_key = f"{model}_Validation"
        test_key = f"{model}_Test"

        for metric in metrics:
            val_score = results[val_key][metric]
            test_score = results[test_key][metric]
            diff = val_score - test_score
            diff_pct = (diff / val_score) * 100 if val_score != 0 else 0

            status = (
                "⚠️  Potential overfitting" if diff_pct > 5 else "✅ Good generalization"
            )
            print(
                f"{metric:12}: Val={val_score:.4f}, Test={test_score:.4f}, "
                f"Diff={diff:+.4f} ({diff_pct:+.1f}%) - {status}"
            )


def get_best_model_summary(results):
    """Summarize which model performs better on each metric"""
    print("\n" + "=" * 70)
    print("MODEL COMPARISON SUMMARY")
    print("=" * 70)

    df = pd.DataFrame(
        {
            k: {
                metric: v
                for metric, v in metrics.items()
                if metric != "Confusion_Matrix"
            }
            for k, metrics in results.items()
        }
    ).T
    metrics = ["ROC_AUC", "PR_AUC", "Precision", "Recall", "F2_Score", "Accuracy"]

    print(f"{'Metric':<12} {'Best on Validation':<20} {'Best on Test':<20}")
    print("-" * 60)

    for metric in metrics:
        # Validation comparison
        lr_val = df.loc[df.index.str.contains("Logistic.*Validation"), metric].values[0]
        cb_val = df.loc[df.index.str.contains("CatBoost.*Validation"), metric].values[0]
        best_val = (
            "Logistic Regression"
            if lr_val > cb_val
            else "CatBoost" if cb_val > lr_val else "Tie"
        )

        # Test comparison
        lr_test = df.loc[df.index.str.contains("Logistic.*Test"), metric].values[0]
        cb_test = df.loc[df.index.str.contains("CatBoost.*Test"), metric].values[0]
        best_test = (
            "Logistic Regression"
            if lr_test > cb_test
            else "CatBoost" if cb_test > lr_test else "Tie"
        )

        print(f"{metric:<12} {best_val:<20} {best_test:<20}")


# Example usage function
def run_complete_evaluation(
    y_val,
    y_test,
    val_pred_lr,
    test_pred_lr,
    threshold_lr,
    val_pred_cb,
    test_pred_cb,
    threshold_cb,
):
    """Run complete evaluation pipeline"""

    # Calculate performance metrics
    results = evaluate_model_performance(
        y_val,
        y_test,
        val_pred_lr,
        test_pred_lr,
        threshold_lr,
        val_pred_cb,
        test_pred_cb,
        threshold_cb,
    )

    # Display results table
    df_results = display_performance_table(results)

    # Create performance comparison visualizations
    plot_performance_comparison(results)

    # Create confusion matrix visualizations
    plot_confusion_matrices(results)

    # Analyze confusion matrices
    analyze_confusion_matrices(results)

    # Analyze overfitting
    analyze_overfitting(results)

    # Show model comparison summary
    get_best_model_summary(results)

    return results, df_results
