import pandas as pd
import numpy as np
from typing import List


# Function to calculate missing values by column# Funct
def missing_values_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    This function calculates missing rate by column.
    Args:
        df (pd.DataFrame): the input data frame

    Returns:
        mis_val_table_ren_columns: the output data frame showing the missing values by column

    """
    # Total missing values
    mis_val = df.isnull().sum()

    # Percentage of missing values
    mis_val_percent = 100 * df.isnull().sum() / len(df)

    # Make a table with the results
    mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)

    # Rename the columns
    mis_val_table_ren_columns = mis_val_table.rename(
        columns={0: "Missing Values", 1: "% of Total Values"}
    )

    # Sort the table by percentage of missing descending
    mis_val_table_ren_columns = (
        mis_val_table_ren_columns[mis_val_table_ren_columns.iloc[:, 1] != 0]
        .sort_values("% of Total Values", ascending=False)
        .round(1)
    )

    # Print some summary information
    print(
        "Your selected dataframe has " + str(df.shape[1]) + " columns.\n"
        "There are "
        + str(mis_val_table_ren_columns.shape[0])
        + " columns that have missing values."
    )

    # Return the dataframe with missing information
    return mis_val_table_ren_columns


def cyclical_encode(df, col, unit_number=30):
    print("-" * 50)
    print("Encoding feature ", col)
    df[col + "_sin"] = np.sin(2 * np.pi * df[col] / unit_number)
    df[col + "_cos"] = np.cos(2 * np.pi * df[col] / unit_number)
    print(f"Encoding feature {col} is finished")
    df = df.drop(columns=col)

    return df

def feat_with_correlation(df: pd.DataFrame, feat_num: List[str], threshold: float = 0.9) -> List[str]:
    """
    Identify features in the DataFrame that have a high correlation with each other.

    Args:
        df (pd.DataFrame): The DataFrame containing the features.
        feat_num (List[str]): List of numerical feature names to check for correlation.
        threshold (float, optional): The correlation threshold above which features are considered highly correlated. Defaults to 0.9.

    Returns:
        List[str]: List of features to remove due to high correlation.
    """
    to_remove = set()
    corr_matrix = df[feat_num].corr().abs()
    for i, feat_a in enumerate(feat_num):
        for j, feat_b in enumerate(feat_num[i+1:], start=i+1):
            if corr_matrix.iloc[i, j] > threshold:
                to_remove.add(feat_b)
                print(f"Feature A: {feat_a}, Feature B: {feat_b} - Correlation: {corr_matrix.iloc[i, j]:.3f}")

    return list(to_remove)
import pandas as pd


def compute_iv_from_woe(data, woe_feature, target_series):
    """
    Estimate IV for a feature that has already been transformed by WOE.

    Parameters:
    data (pd.DataFrame): The dataset containing the WOE-transformed feature.
    woe_feature (str): The name of the WOE-transformed feature.
    target_series (pd.Series): The target variable (binary).

    Returns:
    float: The Information Value (IV) for the WOE-transformed feature.
    """
    # Ensure the target variable is binary
    if not set(target_series).issubset({0, 1}):
        raise ValueError("The target variable must be binary (0 or 1).")

    # Combine the data and target_series into a single DataFrame
    temp_data = data.copy()
    temp_data["target"] = target_series

    # Calculate the distribution of good and bad outcomes for each WOE value
    grouped = (
        temp_data.groupby(woe_feature)
        .agg(
            good=("target", lambda x: (x == 0).sum()),
            bad=("target", lambda x: (x == 1).sum()),
        )
        .reset_index()
    )

    # Calculate the total number of good and bad outcomes
    total_good = grouped["good"].sum()
    total_bad = grouped["bad"].sum()

    # Calculate the Information Value (IV)
    grouped["good_dist"] = grouped["good"] / total_good
    grouped["bad_dist"] = grouped["bad"] / total_bad
    grouped["iv_contribution"] = (grouped["bad_dist"] - grouped["good_dist"]) * grouped[
        woe_feature
    ]

    iv = grouped["iv_contribution"].sum()

    return np.round(iv, 3)

def calculate_iv_no_binning(df, feature, target):
    """
    Calculate the Information Value (IV) for a given feature and binary target without binning.

    Parameters:
    - df: pandas.DataFrame
    - feature: str, the name of the feature column
    - target: str, the name of the target column

    Returns:
    - total_iv: float, the Information Value for the feature
    """
    # Step 1: Calculate the number of good and bad for each unique value of the feature
    value_stats = df.groupby(feature)[target].agg(["count", "sum"])
    value_stats.columns = ["total", "bad"]

    # Calculate good
    value_stats["good"] = value_stats["total"] - value_stats["bad"]

    # Step 2: Calculate proportions
    total_good = value_stats["good"].sum()
    total_bad = value_stats["bad"].sum()

    value_stats["prop_good"] = value_stats["good"] / total_good
    value_stats["prop_bad"] = value_stats["bad"] / total_bad

    # Step 3: Calculate WoE
    value_stats["woe"] = np.log(
        value_stats["prop_good"] / value_stats["prop_bad"]
    ).replace([np.inf, -np.inf], 0)

    # Step 4: Calculate IV for each unique value
    value_stats["iv_value"] = (
        value_stats["prop_good"] - value_stats["prop_bad"]
    ) * value_stats["woe"]

    # Total IV
    total_iv = value_stats["iv_value"].sum()

    return total_iv

def simple_target_encoding_robust(
    df, categorical_col, target_col, smoothing=100, default_value="global_mean"
):
    """
    Simple target encoding with robust handling of unseen categories

    Parameters:
    df: training DataFrame
    categorical_col: column to encode
    target_col: target variable
    smoothing: smoothing parameter
    default_value: 'global_mean', 'median', or specific float value

    Returns:
    encoded_values: encoded values for training set
    encoding_map: dictionary for applying to test set
    """
    # Calculate statistics for each category
    target_stats = df.groupby(categorical_col)[target_col].agg(["mean", "count"])
    global_mean = df[target_col].mean()
    global_median = df[target_col].median()

    # Apply smoothing
    target_stats["smoothed_mean"] = (
        target_stats["count"] * target_stats["mean"] + smoothing * global_mean
    ) / (target_stats["count"] + smoothing)

    # Create encoding map
    encoding_map = target_stats["smoothed_mean"].to_dict()

    # Define default value for unseen categories
    if default_value == "global_mean":
        default_val = global_mean
    elif default_value == "median":
        default_val = global_median
    else:
        default_val = float(default_value)

    # Store metadata
    encoding_metadata = {
        "encoding_map": encoding_map,
        "default_value": default_val,
        "global_mean": global_mean,
        "global_median": global_median,
        "n_categories": len(encoding_map),
        "smoothing": smoothing,
    }

    # Map back to original dataframe
    encoded_values = df[categorical_col].map(encoding_map)

    return encoded_values, encoding_metadata


def apply_target_encoding(series, encoding_metadata):
    """
    Apply target encoding to new data (test set)

    Parameters:
    series: pandas Series to encode
    encoding_metadata: metadata from training encoding

    Returns:
    encoded_series: encoded values
    """
    encoding_map = encoding_metadata["encoding_map"]
    default_value = encoding_metadata["default_value"]

    # Map known categories and fill unseen with default
    encoded_series = series.map(encoding_map).fillna(default_value)

    # Report unseen categories
    unseen_mask = series.map(encoding_map).isnull()
    n_unseen = unseen_mask.sum()

    if n_unseen > 0:
        unseen_categories = series[unseen_mask].unique()
        print(
            f"Found {n_unseen} instances of {len(unseen_categories)} unseen categories"
        )
        print(f"Unseen categories (first 10): {unseen_categories[:10].tolist()}")
        print(f"Filled with default value: {default_value:.4f}")

    return encoded_series