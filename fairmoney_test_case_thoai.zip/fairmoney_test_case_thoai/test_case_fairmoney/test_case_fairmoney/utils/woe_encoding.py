from optbinning import OptimalBinning
import numpy as np
import pandas as pd

from tqdm import tqdm

def calculate_iv_from_bins(feature_values, target_values, binning_model):
    """
    Calculate IV for a dataset using pretrained binning model

    Parameters:
    -----------
    feature_values : array-like
        Feature values to calculate IV for
    target_values : array-like
        Target values (binary)
    binning_model : OptimalBinning
        Fitted binning model

    Returns:
    --------
    float : Information Value
    """
    # Get bin indices for the data
    bin_indices = binning_model.transform(feature_values, metric="indices")

    # Create a dataframe for easier calculation
    temp_df = pd.DataFrame({"bin": bin_indices, "target": target_values})

    # Calculate event rate and non-event rate per bin
    bin_stats = temp_df.groupby("bin")["target"].agg(["sum", "count"])
    bin_stats["non_events"] = bin_stats["count"] - bin_stats["sum"]
    bin_stats["events"] = bin_stats["sum"]

    # Calculate total events and non-events
    total_events = bin_stats["events"].sum()
    total_non_events = bin_stats["non_events"].sum()

    # Avoid division by zero
    if total_events == 0 or total_non_events == 0:
        return 0.0

    # Calculate distribution of events and non-events
    bin_stats["event_rate"] = bin_stats["events"] / total_events
    bin_stats["non_event_rate"] = bin_stats["non_events"] / total_non_events

    # Avoid log(0) by adding small epsilon
    epsilon = 1e-10
    bin_stats["event_rate"] = bin_stats["event_rate"].replace(0, epsilon)
    bin_stats["non_event_rate"] = bin_stats["non_event_rate"].replace(0, epsilon)

    # Calculate WOE and IV per bin
    bin_stats["woe"] = np.log(bin_stats["event_rate"] / bin_stats["non_event_rate"])
    bin_stats["iv"] = (
        bin_stats["event_rate"] - bin_stats["non_event_rate"]
    ) * bin_stats["woe"]

    # Total IV is sum of bin IVs
    total_iv = bin_stats["iv"].sum()

    return total_iv


def woe_encoding_numerical_with_iv(
    df_train,
    df_val,
    df_test,
    feat_num,
    target,
    iv_threshold=0.01,
    binning_params=None,
    plot_event_rate=False,
    verbose=True,
):
    """
    Perform WOE encoding with IV calculation for numerical features across train, validation, and test datasets.

    Parameters:
    -----------
    df_train : pd.DataFrame
        Training dataset
    df_val : pd.DataFrame
        Validation dataset
    df_test : pd.DataFrame
        Test dataset
    feat_num : list
        List of numerical feature names to process
    target : str
        Target variable name
    iv_threshold : float, default=0.01
        Minimum IV value for feature selection
    binning_params : dict, optional
        Parameters for OptimalBinning. If None, uses default parameters for numerical
    plot_event_rate : bool, default=False
        Whether to plot event rate for each feature
    verbose : bool, default=True
        Whether to print progress and results

    Returns:
    --------
    dict : Dictionary containing:
        - 'df_train_woe': WOE-encoded training data
        - 'df_val_woe': WOE-encoded validation data
        - 'df_test_woe': WOE-encoded test data
        - 'df_iv': DataFrame with IV values for all features
        - 'selected_features': List of selected features based on IV threshold
        - 'binning_models': Dictionary of fitted binning models for each feature
    """

    # Set default binning parameters if not provided
    if binning_params is None:
        binning_params = {
            "dtype": "numerical",
            "solver": "cp",
            "min_prebin_size": 0.05,
            "max_n_prebins": 10,
            "time_limit": 200,
        }

    # Initialize lists to collect results
    feature_names_num = []
    iv_values_train = []
    iv_values_val = []
    iv_values_test = []
    train_woe_data = {}
    val_woe_data = {}
    test_woe_data = {}
    binning_models = {}

    # Process each numerical feature
    for feature in feat_num:
        if verbose:
            print(f"Processing feature: {feature}")

        # Create and fit the optimal binning model on TRAIN data only
        binning_model = OptimalBinning(**binning_params)
        binning_model.fit(df_train[feature], df_train[target])

        # Store the binning model
        binning_models[feature] = binning_model

        # Get binning table and IV from training data
        binning_table = binning_model.binning_table
        binning_table.build()
        iv_train = binning_table.iv

        # Plot event rate if requested
        if plot_event_rate:
            binning_table.plot(metric="event_rate")

        # Calculate IV for validation and test sets using the pretrained binning
        iv_val = calculate_iv_from_bins(df_val[feature], df_val[target], binning_model)
        iv_test = calculate_iv_from_bins(
            df_test[feature], df_test[target], binning_model
        )

        # Store feature name and IV values
        feature_names_num.append(feature)
        iv_values_train.append(iv_train)
        iv_values_val.append(iv_val)
        iv_values_test.append(iv_test)

        if verbose:
            print(
                f"  IV - Train: {iv_train:.4f}, Val: {iv_val:.4f}, Test: {iv_test:.4f}"
            )

        # Transform train, validation, and test data using WOE
        train_woe_data[feature] = binning_model.transform(
            df_train[feature], metric="woe"
        )
        val_woe_data[feature] = binning_model.transform(df_val[feature], metric="woe")
        test_woe_data[feature] = binning_model.transform(df_test[feature], metric="woe")

    # Create DataFrames all at once
    df_train_woe = pd.DataFrame(train_woe_data)
    df_val_woe = pd.DataFrame(val_woe_data)
    df_test_woe = pd.DataFrame(test_woe_data)

    # Create DataFrame with numerical features and their IV values for all datasets
    df_iv = pd.DataFrame(
        {
            "features": feature_names_num,
            "IV_train": [round(iv, 4) for iv in iv_values_train],
            "IV_val": [round(iv, 4) for iv in iv_values_val],
            "IV_test": [round(iv, 4) for iv in iv_values_test],
            "IV_avg": [
                round((iv_train + iv_val + iv_test) / 3, 4)
                for iv_train, iv_val, iv_test in zip(
                    iv_values_train, iv_values_val, iv_values_test
                )
            ],
        }
    )

    # Sort by train IV
    df_iv = df_iv.sort_values(by="IV_train", ascending=False)

    # Select features based on train IV
    selected_features = df_iv[df_iv.IV_train > iv_threshold]["features"].tolist()

    # Print summary if verbose
    if verbose:
        print(f"\n{'='*60}")
        print(f"Total numerical features: {len(feat_num)}")
        print(
            f"Selected features (IV_train > {iv_threshold}): {len(selected_features)}"
        )
        print(f"\nWOE-encoded datasets created:")
        print(f"  Train: {df_train_woe.shape}")
        print(f"  Validation: {df_val_woe.shape}")
        print(f"  Test: {df_test_woe.shape}")
        print(f"\nTop 10 features by IV:")
        print(df_iv.head(10).to_string(index=False))

    # Return all results in a dictionary
    return {
        "df_train_woe": df_train_woe,
        "df_val_woe": df_val_woe,
        "df_test_woe": df_test_woe,
        "df_iv": df_iv,
        "selected_features": selected_features,
        "binning_models": binning_models,
    }


def woe_encoding_categorical_with_iv(
    df_train,
    df_val,
    df_test,
    feat_cat,
    target,
    iv_threshold=0.01,
    binning_params=None,
    plot_event_rate=False,
    verbose=True,
    show_progress=True,
    handle_errors=True,
):
    """
    Perform WOE encoding with IV calculation for categorical features across train, validation, and test datasets.

    Parameters:
    -----------
    df_train : pd.DataFrame
        Training dataset
    df_val : pd.DataFrame
        Validation dataset
    df_test : pd.DataFrame
        Test dataset
    feat_cat : list
        List of categorical feature names to process
    target : str
        Target variable name
    iv_threshold : float, default=0.01
        Minimum IV value for feature selection
    binning_params : dict, optional
        Parameters for OptimalBinning. If None, uses default parameters for categorical
    plot_event_rate : bool, default=False
        Whether to plot event rate for each feature
    verbose : bool, default=True
        Whether to print progress and results
    show_progress : bool, default=True
        Whether to show tqdm progress bar
    handle_errors : bool, default=True
        Whether to continue processing if a feature fails (True) or raise exception (False)

    Returns:
    --------
    dict : Dictionary containing:
        - 'df_train_woe': WOE-encoded training data
        - 'df_val_woe': WOE-encoded validation data
        - 'df_test_woe': WOE-encoded test data
        - 'df_iv': DataFrame with IV values for all features (including IV_std)
        - 'selected_features': List of selected features based on IV threshold
        - 'binning_models': Dictionary of fitted binning models for each feature
        - 'failed_features': List of features that failed to process (if handle_errors=True)
    """

    # Set default binning parameters if not provided
    if binning_params is None:
        binning_params = {
            "dtype": "categorical",
            "solver": "cp",
            "min_prebin_size": 0.05,
            "max_n_prebins": 5,
            "time_limit": 200,
        }

    # Initialize lists to collect results
    feature_names_cat = []
    iv_values_train_cat = []
    iv_values_val_cat = []
    iv_values_test_cat = []
    train_woe_cat_data = {}
    val_woe_cat_data = {}
    test_woe_cat_data = {}
    binning_models_cat = {}
    failed_features_cat = []

    # Set up iterator with or without progress bar
    if show_progress:
        iterator = tqdm(feat_cat, desc="WOE Encoding (Categorical)")
    else:
        iterator = feat_cat

    if verbose and not show_progress:
        print(f"Processing {len(feat_cat)} categorical features...")

    # Process each categorical feature
    for feature in iterator:
        try:
            if verbose and not show_progress:
                print(f"\nProcessing feature: {feature}")

            # Create and fit the optimal binning model on TRAIN data only
            binning_model = OptimalBinning(**binning_params)
            binning_model.fit(df_train[feature], df_train[target])

            # Get binning table and IV from training data
            binning_table = binning_model.binning_table
            binning_table.build()
            iv_train = binning_table.iv

            # Plot event rate if requested
            if plot_event_rate:
                binning_table.plot(metric="event_rate")

            # Calculate IV for validation and test sets using the pretrained binning
            iv_val = calculate_iv_from_bins(
                df_val[feature], df_val[target], binning_model
            )
            iv_test = calculate_iv_from_bins(
                df_test[feature], df_test[target], binning_model
            )

            # Store feature name and IV values
            feature_names_cat.append(feature)
            iv_values_train_cat.append(iv_train)
            iv_values_val_cat.append(iv_val)
            iv_values_test_cat.append(iv_test)

            if verbose and not show_progress:
                print(
                    f"  IV - Train: {iv_train:.4f}, Val: {iv_val:.4f}, Test: {iv_test:.4f}"
                )

            # Transform train, validation, and test data using WOE
            train_woe_cat_data[feature] = binning_model.transform(
                df_train[feature], metric="woe"
            )
            val_woe_cat_data[feature] = binning_model.transform(
                df_val[feature], metric="woe"
            )
            test_woe_cat_data[feature] = binning_model.transform(
                df_test[feature], metric="woe"
            )

            # Store the binning model
            binning_models_cat[feature] = binning_model

        except Exception as e:
            error_msg = f"⚠️  Failed to process {feature}: {str(e)}"
            if verbose:
                print(f"\n{error_msg}")

            failed_features_cat.append(feature)

            if not handle_errors:
                raise
            else:
                continue

    # Create DataFrames all at once
    df_train_woe = pd.DataFrame(train_woe_cat_data)
    df_val_woe = pd.DataFrame(val_woe_cat_data)
    df_test_woe = pd.DataFrame(test_woe_cat_data)

    # Create DataFrame with categorical features and their IV values for all datasets
    df_iv = pd.DataFrame(
        {
            "features": feature_names_cat,
            "IV_train": [round(iv, 4) for iv in iv_values_train_cat],
            "IV_val": [round(iv, 4) for iv in iv_values_val_cat],
            "IV_test": [round(iv, 4) for iv in iv_values_test_cat],
            "IV_avg": [
                round((iv_train + iv_val + iv_test) / 3, 4)
                for iv_train, iv_val, iv_test in zip(
                    iv_values_train_cat, iv_values_val_cat, iv_values_test_cat
                )
            ],
            "IV_std": [
                round(np.std([iv_train, iv_val, iv_test]), 4)
                for iv_train, iv_val, iv_test in zip(
                    iv_values_train_cat, iv_values_val_cat, iv_values_test_cat
                )
            ],
        }
    )

    # Sort by train IV
    df_iv = df_iv.sort_values(by="IV_train", ascending=False)

    # Select features based on train IV
    selected_features = df_iv[df_iv.IV_train > iv_threshold]["features"].tolist()

    # Print summary if verbose
    if verbose:
        print(f"\n{'='*60}")
        print(f"✅ Successfully processed: {len(feature_names_cat)} features")
        if failed_features_cat:
            print(f"❌ Failed features: {len(failed_features_cat)}")
            for failed_feat in failed_features_cat:
                print(f"   - {failed_feat}")
        print(f"Total categorical features: {len(feat_cat)}")
        print(
            f"Selected features (IV_train > {iv_threshold}): {len(selected_features)}"
        )
        print(f"\nWOE-encoded datasets created:")
        print(f"  Train: {df_train_woe.shape}")
        print(f"  Validation: {df_val_woe.shape}")
        print(f"  Test: {df_test_woe.shape}")
        print(f"\nTop 10 categorical features by IV:")
        print(df_iv.head(10).to_string(index=False))

    # Return all results in a dictionary
    return {
        "df_train_woe": df_train_woe,
        "df_val_woe": df_val_woe,
        "df_test_woe": df_test_woe,
        "df_iv": df_iv,
        "selected_features": selected_features,
        "binning_models": binning_models_cat,
        "failed_features": failed_features_cat,
    }
