def financial_analysis_summary(TN, FN, FP, TP):
    """
    Calculate financial analysis for loan approval scenarios.

    Parameters:
    -----------
    TN : int - True Negatives (Non-defaults approved - Profit)
    FN : int - False Negatives (Defaults approved - Loss)
    FP : int - False Positives (Non-defaults rejected - Opportunity cost)
    TP : int - True Positives (Defaults rejected - No cost/profit)

    Returns:
    --------
    dict : Financial summary with conservative, moderate, and aggressive scenarios
    """

    # Cost/Profit assumptions
    scenarios = {
        "Conservative": {
            "profit_per_good_loan": 50,
            "cost_per_default": 100,
            "cost_per_false_alarm": 10,
        },
        "Moderate": {
            "profit_per_good_loan": 275,
            "cost_per_default": 2550,
            "cost_per_false_alarm": 30,
        },
        "Aggressive": {
            "profit_per_good_loan": 500,
            "cost_per_default": 5000,
            "cost_per_false_alarm": 50,
        },
    }

    results = {}

    for scenario_name, params in scenarios.items():
        profit_from_good_loans = TN * params["profit_per_good_loan"]
        loss_from_defaults = FN * params["cost_per_default"]
        loss_from_false_alarms = FP * params["cost_per_false_alarm"]

        net_profit = (
            profit_from_good_loans - loss_from_defaults - loss_from_false_alarms
        )

        results[scenario_name] = {
            "profit_from_good_loans": profit_from_good_loans,
            "loss_from_defaults": -loss_from_defaults,
            "loss_from_false_alarms": -loss_from_false_alarms,
            "net_profit": net_profit,
            "TN": TN,
            "FN": FN,
            "FP": FP,
            "params": params,
        }

    return results


def print_financial_summary(TN, FN, FP, TP):
    """
    Print a formatted financial summary table.
    """
    results = financial_analysis_summary(TN, FN, FP, TP)

    print("=" * 100)
    print(f"FINANCIAL ANALYSIS SUMMARY")
    print("=" * 100)
    print(f"\nConfusion Matrix:")
    print(f"  - True Negatives (TN):  {TN} (Non-defaults approved → Profit)")
    print(f"  - False Negatives (FN): {FN} (Defaults approved → Loss)")
    print(f"  - False Positives (FP): {FP} (Non-defaults rejected → Opportunity cost)")
    print(f"  - True Positives (TP):  {TP} (Defaults rejected → No impact)")
    print(f"  - Total Applications:   {TN + FN + FP + TP}")
    print("\n" + "-" * 100)

    # Print table header
    print(
        f"\n{'Component':<35} {'Conservative':>20} {'Moderate':>20} {'Aggressive':>20}"
    )
    print("-" * 100)

    # Extract data for table
    conservative = results["Conservative"]
    moderate = results["Moderate"]
    aggressive = results["Aggressive"]

    # Profit from good loans
    print(
        f"{'Profit from good loans (TN)':<35} "
        f"{TN} × ${conservative['params']['profit_per_good_loan']} = ${conservative['profit_from_good_loans']:>8,} "
        f"{TN} × ${moderate['params']['profit_per_good_loan']} = ${moderate['profit_from_good_loans']:>8,} "
        f"{TN} × ${aggressive['params']['profit_per_good_loan']} = ${aggressive['profit_from_good_loans']:>8,}"
    )

    # Loss from defaults
    print(
        f"{'Loss from defaults (FN)':<35} "
        f"{FN} × ${conservative['params']['cost_per_default']} = ${conservative['loss_from_defaults']:>8,} "
        f"{FN} × ${moderate['params']['cost_per_default']:>4} = ${moderate['loss_from_defaults']:>8,} "
        f"{FN} × ${aggressive['params']['cost_per_default']:>4} = ${aggressive['loss_from_defaults']:>8,}"
    )

    # Loss from false alarms
    print(
        f"{'Loss from false alarms (FP)':<35} "
        f"{FP} × ${conservative['params']['cost_per_false_alarm']} = ${conservative['loss_from_false_alarms']:>8,} "
        f"{FP} × ${moderate['params']['cost_per_false_alarm']} = ${moderate['loss_from_false_alarms']:>8,} "
        f"{FP} × ${aggressive['params']['cost_per_false_alarm']} = ${aggressive['loss_from_false_alarms']:>8,}"
    )

    print("-" * 100)

    # Net profit/loss
    print(
        f"{'NET PROFIT/LOSS':<35} "
        f"${conservative['net_profit']:>18,} "
        f"${moderate['net_profit']:>18,} "
        f"${aggressive['net_profit']:>18,}"
    )

    print("=" * 100)

    return results
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import seaborn as sns


def calculate_net_profit(TN, FN, FP, TP, scenario="Moderate"):
    """
    Calculate net profit for a given confusion matrix.

    Parameters:
    -----------
    TN, FN, FP, TP : int
        Confusion matrix values
    scenario : str
        'Conservative', 'Moderate', or 'Aggressive'

    Returns:
    --------
    float : Net profit/loss
    """
    scenarios = {
        "Conservative": {
            "profit_per_good_loan": 50,
            "cost_per_default": 100,
            "cost_per_false_alarm": 10,
        },
        "Moderate": {
            "profit_per_good_loan": 275,
            "cost_per_default": 2550,
            "cost_per_false_alarm": 30,
        },
        "Aggressive": {
            "profit_per_good_loan": 500,
            "cost_per_default": 5000,
            "cost_per_false_alarm": 50,
        },
    }

    params = scenarios[scenario]

    profit_from_good_loans = TN * params["profit_per_good_loan"]
    loss_from_defaults = FN * params["cost_per_default"]
    loss_from_false_alarms = FP * params["cost_per_false_alarm"]

    net_profit = profit_from_good_loans - loss_from_defaults - loss_from_false_alarms

    return net_profit, params


def find_optimal_threshold(
    y_true, y_pred_proba, scenario="Moderate", thresholds=None, plot=True
):
    """
    Find the optimal threshold that maximizes net profit.

    Parameters:
    -----------
    y_true : array-like
        True labels (0 = non-default, 1 = default)
    y_pred_proba : array-like
        Predicted probabilities of default
    scenario : str
        'Conservative', 'Moderate', or 'Aggressive'
    thresholds : array-like, optional
        Custom threshold values to test. If None, uses np.linspace(0, 1, 101)
    plot : bool
        Whether to generate plots

    Returns:
    --------
    dict : Results including optimal threshold, max profit, and all threshold results
    """

    if thresholds is None:
        thresholds = np.linspace(0, 1, 101)

    results = []

    for threshold in thresholds:
        # Convert probabilities to predictions based on threshold
        y_pred = (y_pred_proba >= threshold).astype(int)

        # Calculate confusion matrix
        # Note: In loan context, we predict 1 for "default" (reject), 0 for "non-default" (approve)
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()

        # Calculate net profit
        net_profit, params = calculate_net_profit(tn, fn, fp, tp, scenario)

        # Store results
        results.append(
            {
                "threshold": threshold,
                "TN": tn,
                "FP": fp,
                "FN": fn,
                "TP": tp,
                "net_profit": net_profit,
                "total_approved": tn + fn,
                "total_rejected": fp + tp,
                "approval_rate": (tn + fn) / len(y_true),
            }
        )

    # Convert to DataFrame
    df_results = pd.DataFrame(results)

    # Find optimal threshold
    optimal_idx = df_results["net_profit"].idxmax()
    optimal_result = df_results.iloc[optimal_idx]

    # Print summary
    print("=" * 80)
    print(f"OPTIMAL THRESHOLD ANALYSIS ({scenario})")
    print("=" * 80)
    print(f"\nOptimal Threshold: {optimal_result['threshold']:.3f}")
    print(f"Maximum Net Profit: ${optimal_result['net_profit']:,.0f}")
    print(f"\nConfusion Matrix at Optimal Threshold:")
    print(
        f"  - True Negatives (TN):  {optimal_result['TN']:.0f} (Non-defaults approved → Profit)"
    )
    print(
        f"  - False Negatives (FN): {optimal_result['FN']:.0f} (Defaults approved → Loss)"
    )
    print(
        f"  - False Positives (FP): {optimal_result['FP']:.0f} (Non-defaults rejected → Opportunity cost)"
    )
    print(
        f"  - True Positives (TP):  {optimal_result['TP']:.0f} (Defaults rejected → Avoided loss)"
    )
    print(f"\nApproval Rate: {optimal_result['approval_rate']:.1%}")
    print(f"Total Approved: {optimal_result['total_approved']:.0f}")
    print(f"Total Rejected: {optimal_result['total_rejected']:.0f}")
    print("=" * 80)

    # Create plots if requested
    if plot:
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))

        # Plot 1: Net Profit vs Threshold
        ax1 = axes[0, 0]
        ax1.plot(
            df_results["threshold"],
            df_results["net_profit"],
            linewidth=2,
            color="#2E86AB",
        )
        ax1.axvline(
            optimal_result["threshold"],
            color="red",
            linestyle="--",
            linewidth=2,
            label=f'Optimal: {optimal_result["threshold"]:.3f}',
        )
        ax1.axhline(0, color="gray", linestyle="-", linewidth=0.5, alpha=0.5)
        ax1.scatter(
            optimal_result["threshold"],
            optimal_result["net_profit"],
            color="red",
            s=200,
            zorder=5,
            marker="*",
        )
        ax1.set_xlabel("Threshold", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Net Profit ($)", fontsize=12, fontweight="bold")
        ax1.set_title(
            f"Net Profit vs Threshold ({scenario})", fontsize=14, fontweight="bold"
        )
        ax1.legend(fontsize=10)
        ax1.grid(True, alpha=0.3)
        ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f"${x:,.0f}"))

        # Plot 2: Confusion Matrix Components vs Threshold
        ax2 = axes[0, 1]
        ax2.plot(
            df_results["threshold"],
            df_results["TN"],
            label="TN (Profit)",
            linewidth=2,
            color="#06A77D",
        )
        ax2.plot(
            df_results["threshold"],
            df_results["FN"],
            label="FN (Loss)",
            linewidth=2,
            color="#D62246",
        )
        ax2.plot(
            df_results["threshold"],
            df_results["FP"],
            label="FP (Opp. Cost)",
            linewidth=2,
            color="#F77F00",
        )
        ax2.plot(
            df_results["threshold"],
            df_results["TP"],
            label="TP (Avoided Loss)",
            linewidth=2,
            color="#4A4E69",
        )
        ax2.axvline(
            optimal_result["threshold"],
            color="red",
            linestyle="--",
            linewidth=2,
            alpha=0.7,
        )
        ax2.set_xlabel("Threshold", fontsize=12, fontweight="bold")
        ax2.set_ylabel("Count", fontsize=12, fontweight="bold")
        ax2.set_title(
            "Confusion Matrix Components vs Threshold", fontsize=14, fontweight="bold"
        )
        ax2.legend(fontsize=10)
        ax2.grid(True, alpha=0.3)

        # Plot 3: Approval Rate vs Threshold
        ax3 = axes[1, 0]
        color = "#2E86AB"
        ax3.plot(
            df_results["threshold"],
            df_results["approval_rate"] * 100,
            linewidth=2,
            color=color,
        )
        ax3.axvline(
            optimal_result["threshold"],
            color="red",
            linestyle="--",
            linewidth=2,
            label=f'Optimal: {optimal_result["threshold"]:.3f}',
        )
        ax3.scatter(
            optimal_result["threshold"],
            optimal_result["approval_rate"] * 100,
            color="red",
            s=200,
            zorder=5,
            marker="*",
        )
        ax3.set_xlabel("Threshold", fontsize=12, fontweight="bold")
        ax3.set_ylabel("Approval Rate (%)", fontsize=12, fontweight="bold", color=color)
        ax3.set_title("Approval Rate vs Threshold", fontsize=14, fontweight="bold")
        ax3.tick_params(axis="y", labelcolor=color)
        ax3.legend(fontsize=10)
        ax3.grid(True, alpha=0.3)

        # Plot 4: Net Profit Comparison Across All Scenarios
        ax4 = axes[1, 1]

        # Calculate for all scenarios
        scenarios_to_compare = ["Conservative", "Moderate", "Aggressive"]
        colors_scenarios = ["#06A77D", "#2E86AB", "#D62246"]

        for scenario_name, color in zip(scenarios_to_compare, colors_scenarios):
            scenario_profits = []
            for threshold in thresholds:
                y_pred = (y_pred_proba >= threshold).astype(int)
                tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
                net_profit, _ = calculate_net_profit(tn, fn, fp, tp, scenario_name)
                scenario_profits.append(net_profit)

            ax4.plot(
                thresholds,
                scenario_profits,
                linewidth=2,
                label=scenario_name,
                color=color,
            )

        ax4.axvline(
            optimal_result["threshold"],
            color="red",
            linestyle="--",
            linewidth=2,
            alpha=0.7,
            label=f'Optimal (Mod): {optimal_result["threshold"]:.3f}',
        )
        ax4.axhline(0, color="gray", linestyle="-", linewidth=0.5, alpha=0.5)
        ax4.set_xlabel("Threshold", fontsize=12, fontweight="bold")
        ax4.set_ylabel("Net Profit ($)", fontsize=12, fontweight="bold")
        ax4.set_title(
            "Net Profit Comparison: All Scenarios", fontsize=14, fontweight="bold"
        )
        ax4.legend(fontsize=10)
        ax4.grid(True, alpha=0.3)
        ax4.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f"${x:,.0f}"))

        plt.tight_layout()
        plt.show()

    return {
        "optimal_threshold": optimal_result["threshold"],
        "max_net_profit": optimal_result["net_profit"],
        "optimal_confusion_matrix": {
            "TN": optimal_result["TN"],
            "FP": optimal_result["FP"],
            "FN": optimal_result["FN"],
            "TP": optimal_result["TP"],
        },
        "approval_rate": optimal_result["approval_rate"],
        "all_results": df_results,
    }
import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns


def print_confusion_matrix(y_true, y_pred_proba, threshold=0.5, plot=True):
    """
    Print confusion matrix given predictions, target, and threshold.

    Parameters:
    -----------
    y_true : array-like
        True labels (0 = non-default, 1 = default)
    y_pred_proba : array-like
        Predicted probabilities of default
    threshold : float
        Classification threshold (default: 0.5)
    plot : bool
        Whether to plot the confusion matrix

    Returns:
    --------
    dict : Confusion matrix values (TN, FP, FN, TP)
    """

    # Convert probabilities to binary predictions
    y_pred = (y_pred_proba >= threshold).astype(int)

    # Calculate confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()

    total = tn + fp + fn + tp

    # Print confusion matrix
    print("=" * 80)
    print(f"CONFUSION MATRIX (Threshold = {threshold:.3f})")
    print("=" * 80)
    print(f"\n{'':25} | {'Predicted: 0 (Approve)':>25} | {'Predicted: 1 (Reject)':>25}")
    print("-" * 80)
    print(f"{'Actual: 0 (Non-default)':25} | {tn:>20} (TN) | {fp:>20} (FP)")
    print(f"{'Actual: 1 (Default)':25} | {fn:>20} (FN) | {tp:>20} (TP)")
    print("=" * 80)

    # Print detailed breakdown
    print(f"\nTotal Samples: {total}")
    print(f"\nConfusion Matrix Breakdown:")
    print(
        f"  • TN (True Negative):  {tn:>4} ({tn/total*100:>5.1f}%) - Non-defaults approved ✓ → PROFIT"
    )
    print(
        f"  • FP (False Positive): {fp:>4} ({fp/total*100:>5.1f}%) - Non-defaults rejected ✗ → OPPORTUNITY COST"
    )
    print(
        f"  • FN (False Negative): {fn:>4} ({fn/total*100:>5.1f}%) - Defaults approved ✗ → LOSS"
    )
    print(
        f"  • TP (True Positive):  {tp:>4} ({tp/total*100:>5.1f}%) - Defaults rejected ✓ → AVOIDED LOSS"
    )

    # Calculate metrics
    accuracy = (tn + tp) / total
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    f1 = (
        2 * (precision * recall) / (precision + recall)
        if (precision + recall) > 0
        else 0
    )

    print(f"\nPerformance Metrics:")
    print(f"  • Accuracy:    {accuracy:.3f} ({accuracy*100:.1f}%)")
    print(f"  • Precision:   {precision:.3f} ({precision*100:.1f}%)")
    print(f"  • Recall/TPR:  {recall:.3f} ({recall*100:.1f}%)")
    print(f"  • Specificity: {specificity:.3f} ({specificity*100:.1f}%)")
    print(f"  • F1-Score:    {f1:.3f}")

    approval_rate = (tn + fn) / total
    rejection_rate = (fp + tp) / total

    print(f"\nLoan Decision Rates:")
    print(
        f"  • Approval Rate:  {approval_rate:.3f} ({approval_rate*100:.1f}%) - {tn + fn} loans"
    )
    print(
        f"  • Rejection Rate: {rejection_rate:.3f} ({rejection_rate*100:.1f}%) - {fp + tp} loans"
    )

    print("=" * 80)

    # Plot if requested
    if plot:
        fig, ax = plt.subplots(figsize=(10, 8))

        # Create annotation array with counts and percentages
        annot = np.array(
            [
                [
                    f"TN\n{tn}\n({tn/total*100:.1f}%)",
                    f"FP\n{fp}\n({fp/total*100:.1f}%)",
                ],
                [
                    f"FN\n{fn}\n({fn/total*100:.1f}%)",
                    f"TP\n{tp}\n({tp/total*100:.1f}%)",
                ],
            ]
        )

        # Plot heatmap
        sns.heatmap(
            cm,
            annot=annot,
            fmt="",
            cmap="Blues",
            xticklabels=["Predicted: 0 (Approve)", "Predicted: 1 (Reject)"],
            yticklabels=["Actual: 0 (Non-default)", "Actual: 1 (Default)"],
            cbar_kws={"label": "Count"},
            linewidths=3,
            linecolor="white",
            square=True,
            ax=ax,
        )

        ax.set_title(
            f"Confusion Matrix (Threshold = {threshold:.3f})",
            fontsize=16,
            fontweight="bold",
            pad=20,
        )
        ax.set_ylabel("Actual", fontsize=13, fontweight="bold")
        ax.set_xlabel("Predicted", fontsize=13, fontweight="bold")

        plt.tight_layout()
        plt.show()

    return {
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "TP": tp,
        "threshold": threshold,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
        "approval_rate": approval_rate,
    }