import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency

def cramers_v1(x, y):
    """
    Calculate Cramér's V between two categorical variables

    Parameters:
    x, y: array-like, categorical variables

    Returns:
    float: Cramér's V value (0-1)
    """
    # Create contingency table
    contingency_table = pd.crosstab(x, y)

    # Calculate chi-square
    chi2, p_value, dof, expected = chi2_contingency(contingency_table)

    # Get dimensions
    n = contingency_table.sum().sum()  # total observations
    r, k = contingency_table.shape  # rows, columns

    # Calculate Cramér's V
    cramers_v = np.sqrt(chi2 / (n * min(k - 1, r - 1)))

    return contingency_table, cramers_v
