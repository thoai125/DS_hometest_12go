import math
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from catboost import CatBoostClassifier


def analyze_shap_interactions(
    model, X_test, feature_5, shap_values, n_important_features=2
):
    """
    Analyze and visualize main effects and interaction effects using SHAP values.

    Parameters:
    -----------
    model : trained model object
        The model to explain with SHAP
    X_test : pandas DataFrame
        Test data with features
    feature_5 : list
        List of feature names
    shap_values : numpy array
        Pre-computed SHAP values for the test data
    n_important_features : int, optional
        Number of important features to analyze (default: 2)

    Returns:
    --------
    fig : matplotlib figure
        The generated figure with main effects and interactions
    """

    # Calculate interaction values
    interaction_values = shap.TreeExplainer(model).shap_interaction_values(
        X_test[feature_5]
    )

    # Select a few important features to analyze
    important_features = feature_5[:n_important_features]  # Use first n features
    n_features = len(important_features)

    # Create a figure with a grid of plots
    # For each feature: main effect + interactions with other features
    fig, axes = plt.subplots(
        n_features, n_features, figsize=(10 * n_features, 10 * n_features)
    )

    # Handle the case with only one feature
    if n_features == 1:
        axes = np.array([[axes]])

    # Loop through the grid
    for i in range(n_features):
        for j in range(n_features):
            feature_i = important_features[i]
            feature_j = important_features[j]

            idx_i = feature_5.index(feature_i)
            idx_j = feature_5.index(feature_j)

            plt.sca(axes[i, j])

            if i == j:  # Diagonal: show main effect
                shap.dependence_plot(
                    ind=idx_i,
                    shap_values=shap_values,
                    features=X_test[feature_5],
                    feature_names=feature_5,
                    ax=axes[i, j],
                    show=False,
                )
                axes[i, j].set_title(f"Main effect: {feature_i}")
            else:  # Off-diagonal: show interaction
                shap.dependence_plot(
                    (idx_i, idx_j),
                    interaction_values,
                    X_test[feature_5],
                    feature_names=feature_5,
                    ax=axes[i, j],
                    show=False,
                )
                axes[i, j].set_title(f"Interaction: {feature_i} × {feature_j}")

    # Adjust layout
    plt.tight_layout()
    plt.subplots_adjust(top=0.9)
    fig.suptitle("Main Effects and Interactions Analysis", fontsize=16)

    return fig


def plot_top_shap_interactions(model, X_test, feature_names, n_top_interactions=9):
    """
    Plot the top feature interactions based on SHAP interaction values.

    Parameters:
    -----------
    model : fitted model object
        The trained model to explain (must be compatible with shap.TreeExplainer)
    X_test : pandas DataFrame or numpy array
        The test data to compute SHAP values for
    feature_names : list
        List of feature names to use
    n_top_interactions : int, optional
        Number of top interactions to plot (default: 9)

    Returns:
    --------
    fig : matplotlib Figure
        The figure containing the plots
    """

    # Calculate the SHAP interaction values
    interaction_values = shap.TreeExplainer(model).shap_interaction_values(
        X_test[feature_names]
    )

    # Measure interaction strength (average absolute interaction SHAP values)
    interaction_strength = np.abs(interaction_values).mean(axis=0)
    np.fill_diagonal(
        interaction_strength, 0
    )  # Zero out the diagonal (self-interactions)

    # Get the top N strongest interactions
    flat_indices = np.argsort(interaction_strength.flatten())[-n_top_interactions:]
    feature_pairs = []

    for flat_idx in flat_indices[::-1]:  # Reverse to get strongest first
        # Convert flat index to 2D indices
        i, j = np.unravel_index(flat_idx, interaction_strength.shape)
        if i < j:  # Avoid duplicates (interaction matrix is symmetric)
            feature_pairs.append(
                (feature_names[i], feature_names[j], interaction_strength[i, j])
            )
        else:
            feature_pairs.append(
                (feature_names[j], feature_names[i], interaction_strength[i, j])
            )

    # Define grid layout
    n_cols = 2  # Number of plots per row
    n_rows = math.ceil(len(feature_pairs) / n_cols)  # Calculate required number of rows

    # Create figure with subplots
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 6 * n_rows))

    # Ensure axes is always a 2D array even with a single row
    if n_rows == 1:
        axes = np.array([axes])

    # Flatten axes array for easier indexing
    axes = axes.flatten()

    # Loop through feature pairs and create interaction plots
    for i, (feature1, feature2, strength) in enumerate(feature_pairs):
        # Get the current axis
        ax = axes[i]

        # Get feature indices
        idx1 = feature_names.index(feature1)
        idx2 = feature_names.index(feature2)

        # Create SHAP interaction plot
        plt.sca(ax)
        shap.dependence_plot(
            (idx1, idx2),
            interaction_values,
            X_test[feature_names],
            feature_names=feature_names,
            ax=ax,
            show=False,
        )

        # Add title with interaction strength
        ax.set_title(f"#{i+1}: {feature1} × {feature2}\nStrength: {strength:.4f}")

    # Hide any unused subplots
    for i in range(len(feature_pairs), n_rows * n_cols):
        axes[i].set_visible(False)

    # Add an overall title
    fig.suptitle("Top Feature Interactions by SHAP Strength", fontsize=16, y=1.02)

    # Adjust layout
    plt.tight_layout()

    return fig


def plot_shap_dependence_grid(
    feature_list,
    shap_values,
    X_test,
    feature_names=None,
    n_cols=2,
    overall_title="Feature Impact Analysis using SHAP",
    is_categorical=False,
):
    """
    Plots SHAP dependence plots for a list of features in a grid layout.

    Parameters
    ----------
    feature_list : list or str
        List of features to plot (must be subset of feature_names).
        If string is passed, it will be converted to a single-item list.
    shap_values : np.ndarray or pandas.DataFrame
        SHAP values for the samples.
    X_test : pandas.DataFrame
        Test feature data (columns should include feature_list).
    feature_names : list, optional
        Full list of feature names (default uses X_test.columns).
    n_cols : int, optional
        Number of columns in the subplot grid.
    overall_title : str, optional
        Main title for the figure.
    is_categorical : bool, optional
        Whether features are categorical (affects plotting method).
    """
    # Handle string input - convert to list
    if isinstance(feature_list, str):
        feature_list = [feature_list]

    if len(feature_list) == 0:
        print("No features to treat")
        return

    # Set feature_names to X_test columns if not provided
    if feature_names is None:
        feature_names = list(X_test.columns)

    # Validate that all features in feature_list exist in feature_names
    missing_features = [f for f in feature_list if f not in feature_names]
    if missing_features:
        print(
            f"Error: The following features are not in feature_names: {missing_features}"
        )
        print(f"Available features: {feature_names}")
        return

    n_features = len(feature_list)
    n_rows = math.ceil(n_features / n_cols)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 6 * n_rows))

    # Handle axes indexing for different subplot configurations
    if n_rows * n_cols == 1:
        axes_flat = [axes]
    elif n_rows == 1:
        axes_flat = axes
    else:
        axes_flat = axes.flatten()

    if is_categorical is False:
        for i, feature in enumerate(feature_list):
            ax = axes_flat[i]
            try:
                shap.dependence_plot(
                    ind=feature,
                    shap_values=shap_values,
                    features=X_test[feature_names],
                    #feature_names=feature_names,
                    ax=ax,
                    show=False,
                )
                ax.set_title(f"SHAP Dependence: {feature}")
            except Exception as e:
                print(f"Error plotting feature '{feature}': {e}")
                ax.text(
                    0.5,
                    0.5,
                    f"Error plotting\n{feature}",
                    ha="center",
                    va="center",
                    transform=ax.transAxes,
                )
    else:
        for i, feature in enumerate(feature_list):
            row = i // n_cols
            col = i % n_cols
            feature_idx = feature_names.index(feature)

            try:
                shap.dependence_plot(
                    feature_idx,
                    shap_values,
                    X_test,
                    title=f"Dependence: {feature}",
                    ax=axes[row, col] if n_rows > 1 else axes_flat[i],
                    show=False,
                    interaction_index=None,
                )
            except Exception as e:
                print(f"Error plotting feature '{feature}': {e}")
                ax = axes[row, col] if n_rows > 1 else axes_flat[i]
                ax.text(
                    0.5,
                    0.5,
                    f"Error plotting\n{feature}",
                    ha="center",
                    va="center",
                    transform=ax.transAxes,
                )

    # Hide unused subplots
    if n_rows * n_cols > 1:
        for i in range(n_features, n_rows * n_cols):
            axes_flat[i].set_visible(False)

    fig.suptitle(overall_title, fontsize=16, y=1.02)
    plt.tight_layout()
    plt.show()


def create_dependence_plots(
    X_test: pd.DataFrame,
    shap_values: np.ndarray,
    numerical_features: List[str],
    categorical_features: List[str],
) -> Tuple[plt.Figure, plt.Figure]:
    """
    Create SHAP dependence plots for feature analysis, separating numerical and categorical features

    Args:
        X_test: Test data with features
        shap_values: Calculated SHAP values
        numerical_features: List of numerical feature names
        categorical_features: List of categorical feature names

    Returns:
        Tuple of two figures: (numerical_features_plot, categorical_features_plot)
    """
    # Create plot for numerical features
    if numerical_features:
        X_num = X_test[numerical_features]

        # Determine grid size based on number of numerical features
        num_features = len(numerical_features)
        num_cols = min(2, num_features)
        num_rows = (num_features + num_cols - 1) // num_cols  # Ceiling division

        fig_num = plt.figure(figsize=(15, num_rows * 7))

        for i, feature_name in enumerate(numerical_features):
            ax = plt.subplot(num_rows, num_cols, i + 1)
            feature_idx = list(X_test.columns).index(feature_name)

            shap.dependence_plot(
                feature_idx,
                shap_values,
                X_test,
                title=f"Dependence: {feature_name}",
                ax=ax,
                show=False,
                interaction_index=None,
            )

        plt.tight_layout()
    else:
        fig_num = plt.figure(figsize=(10, 5))
        plt.text(
            0.5,
            0.5,
            "No numerical features available",
            horizontalalignment="center",
            verticalalignment="center",
        )

    # Create plot for categorical features
    if categorical_features:
        X_cat = X_test[categorical_features]

        # Determine grid size based on number of categorical features
        cat_features = len(categorical_features)
        cat_cols = min(2, cat_features)
        cat_rows = (cat_features + cat_cols - 1) // cat_cols  # Ceiling division

        fig_cat = plt.figure(figsize=(15, cat_rows * 7))

        for i, feature_name in enumerate(categorical_features):
            ax = plt.subplot(cat_rows, cat_cols, i + 1)
            feature_idx = list(X_test.columns).index(feature_name)

            shap.dependence_plot(
                feature_idx,
                shap_values,
                X_test,
                title=f"Dependence: {feature_name}",
                ax=ax,
                show=False,
                interaction_index=None,
            )

        plt.tight_layout()
    else:
        fig_cat = plt.figure(figsize=(10, 5))
        plt.text(
            0.5,
            0.5,
            "No categorical features available",
            horizontalalignment="center",
            verticalalignment="center",
        )

    return fig_num, fig_cat


def analyze_model_explainability(
    model: CatBoostClassifier,
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: np.ndarray,
    y_test: np.ndarray,
    train_pred: np.ndarray,
    test_pred: np.ndarray,
    threshold: float = 0.5,
    max_waterfall_features: int = 15,
    waterfall_samples_per_category: int = 3,
) -> Dict:
    """
    Perform comprehensive model explainability analysis including SHAP values,
    dependence plots, and waterfall plots for each prediction category.

    Args:
        model: Trained CatBoost model
        X_train: Training features
        X_test: Test features
        y_train: Training target values
        y_test: Test target values
        train_pred: Prediction probabilities on training data
        test_pred: Prediction probabilities on test data
        threshold: Classification threshold for predictions
        max_waterfall_features: Maximum number of features to display in waterfall plots
        waterfall_samples_per_category: Number of sample waterfall plots per category

    Returns:
        Dict containing analysis results and plots
    """
    # Get feature lists from model
    feature_names = X_test.columns.tolist()

    # Identify categorical features based on model's cat_features attribute
    cat_features_idx = model.get_cat_feature_indices()
    categorical_features = (
        [feature_names[i] for i in cat_features_idx] if cat_features_idx else []
    )
    numerical_features = [f for f in feature_names if f not in categorical_features]

    # Calculate SHAP values
    explainer = shap.Explainer(model)
    shap_values = explainer(X_test).values

    # Handle missing values in the test data for visualization
    X_test_processed = X_test.copy()

    # Fill numeric NAs with 0 (or other appropriate strategy)
    for feat in numerical_features:
        if X_test_processed[feat].isna().any():
            X_test_processed[feat] = X_test_processed[feat].fillna(0)

    # Fill categorical NAs with a placeholder
    for feat in categorical_features:
        if X_test_processed[feat].isna().any():
            X_test_processed[feat] = X_test_processed[feat].fillna("Unknown")

    # Create dependence plots
    # num_fig, cat_fig = create_dependence_plots(
    #     X_test_processed, shap_values, numerical_features, categorical_features
    # )

    # Prepare prediction analysis
    y_pred_binary = (test_pred > threshold).astype(int)

    # Create dataframe for prediction analysis
    df_explore = X_test.copy()
    df_explore["pred_proba"] = test_pred
    df_explore["y_pred"] = y_pred_binary
    df_explore["y_true"] = y_test

    # Analysis for different prediction categories
    analysis_categories = {
        "false_negatives": (df_explore["y_pred"] == 0) & (df_explore["y_true"] == 1),
        "false_positives": (df_explore["y_pred"] == 1) & (df_explore["y_true"] == 0),
        "true_positives": (df_explore["y_pred"] == 1) & (df_explore["y_true"] == 1),
        "true_negatives": (df_explore["y_pred"] == 0) & (df_explore["y_true"] == 0),
    }

    # # Create waterfall plots for each category
    # waterfall_plots = create_waterfall_plots(
    #     explainer=explainer,
    #     X_data=X_test_processed,
    #     categories=analysis_categories,
    #     original_data=X_test,
    #     prediction_probas=pd.Series(test_pred),
    #     y_true=pd.Series(y_test),
    #     max_display=max_waterfall_features,
    #     samples_per_category=waterfall_samples_per_category,
    # )

    # Calculate feature importance
    feature_importance = pd.DataFrame(
        {"Feature": feature_names, "Importance": model.get_feature_importance()}
    ).sort_values("Importance", ascending=False)

    # Compile results
    analysis_results = {
        "model": model,
        "explainer": explainer,
        "shap_values": shap_values,
        "feature_names": feature_names,
        "numerical_features": numerical_features,
        "categorical_features": categorical_features,
        # "dependence_plots": {
        #     "numerical_features": num_fig,
        #     "categorical_features": cat_fig,
        # },
        #  "waterfall_plots": waterfall_plots,
        "feature_importance": feature_importance,
        "prediction_analysis": {
            category: df_explore.loc[mask, feature_names + ["pred_proba"]]
            for category, mask in analysis_categories.items()
        },
        "test_data": X_test_processed,
        "prediction_categories": {
            "counts": {
                category: mask.sum() for category, mask in analysis_categories.items()
            },
            "percentages": {
                category: mask.mean() * 100
                for category, mask in analysis_categories.items()
            },
        },
    }

    return analysis_results


def display_waterfall_results(results):
    """
    Display waterfall plots and their corresponding data in an alternating pattern

    Args:
        results: Results from analyze_model_explainability
    """
    # Display category statistics first
    print("\nPrediction Category Statistics:")
    for category, count in results["prediction_categories"]["counts"].items():
        percentage = results["prediction_categories"]["percentages"][category]
        print(
            f"{category.replace('_', ' ').title()}: {count} samples ({percentage:.2f}%)"
        )

    # Display waterfall plots and feature values for each category
    for category, plot_data in results["waterfall_plots"].items():
        print(f"\n{'='*80}")
        print(f"{category.replace('_', ' ').title()} - {len(plot_data)} samples")
        print(f"{'='*80}")

        # For each sample in this category
        for i, (fig, sample_data) in enumerate(plot_data):
            print(f"\n{'-'*40}")
            print(f"Sample {i+1} - {category.replace('_', ' ').title()}")
            print(f"{'-'*40}")

            # Display prediction probability and true value
            print(
                f"Prediction Probability: {sample_data['prediction_probability'].values[0]:.4f}"
            )
            print(f"True Value: {int(sample_data['true_value'].values[0])}")

            # Display the waterfall plot
            fig.show()
