from dataclasses import dataclass
from typing import Literal

import matplotlib.pyplot as plt
import seaborn as sns

import pandas as pd

import numpy as np
import numpy.typing as npt
import plotly.express as px
import plotly.graph_objects as go
import polars as pl
from catboost import CatBoostClassifier
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    auc,
    fbeta_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


@dataclass
class ModelPrediction:
    population_name: str
    y_true: npt.NDArray
    y_pred: npt.NDArray


def get_training_performance_curve(
    model: CatBoostClassifier, eval_metric: Literal["PRAUC", "Logloss"]
) -> go.Figure:
    evals_result = model.get_evals_result()

    evals_df = pl.DataFrame(
        {
            "Iterations": range(len(evals_result["learn"][eval_metric])),
            f"Training {eval_metric}": evals_result["learn"][eval_metric],
            f"Validation {eval_metric}": evals_result["validation"][eval_metric],
        }
    )

    evals_plot = px.line(
        evals_df,
        x="Iterations",
        y=[f"Training {eval_metric}", f"Validation {eval_metric}"],
        labels={"value": eval_metric, "variable": "Dataset"},
        title=f"Training and Validation {eval_metric} Over Iterations",
    )

    evals_plot.add_vline(
        x=model.get_best_iteration(),
        line_dash="dash",
        line_color="red",
        annotation_text="Early Stopping",
        annotation_position="top left",
    )

    return evals_plot


def print_training_performance_info(predictions: list[ModelPrediction]) -> None:
    for pred in predictions:
        prec, rec, _ = precision_recall_curve(pred.y_true, pred.y_pred)
        pr_auc = auc(rec, prec)

        print(f"{pred.population_name} PR AUC: {pr_auc:.3f}")


def get_prauc_curve(predictions: list[ModelPrediction]) -> go.Figure:
    pr_curve = go.Figure()

    for pred in predictions:
        prec, rec, _ = precision_recall_curve(pred.y_true, pred.y_pred)
        pr_auc = auc(rec, prec)

        pr_curve.add_trace(
            go.Scatter(
                x=rec,
                y=prec,
                mode="lines",
                name=f"{pred.population_name} PR AUC: {pr_auc:.3f}",
            )
        )

    return pr_curve


def get_roc_auc_curve(predictions: list[ModelPrediction]) -> go.Figure:
    auc_curve = go.Figure()
    auc_curve.add_shape(
        type="line",
        x0=0,
        y0=0,
        x1=1,
        y1=1,
        line={"color": "black", "width": 2, "dash": "dash"},
    )

    for pred in predictions:
        fpr, tpr, _ = roc_curve(pred.y_true, pred.y_pred)
        roc_auc = roc_auc_score(pred.y_true, pred.y_pred)

        auc_curve.add_trace(
            go.Scatter(
                x=fpr,
                y=tpr,
                name=f"{pred.population_name.capitalize()} ROC AUC: {roc_auc:.3f}",
            )
        )

    return auc_curve


def print_info_matrix(
    prediction: ModelPrediction,
    threshold: float,
    beta: float,
) -> None:
    y_true = prediction.y_true
    y_pred = prediction.y_pred > threshold

    prec = precision_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred)
    acc = accuracy_score(y_true, y_pred)
    fbeta = fbeta_score(y_true, y_pred, beta=beta)

    print(f"Confusion Matrix ({prediction.population_name})")
    print(f"Threshold: {threshold:.3f}")
    print(f"Accuracy: {acc:.3f}")
    print(f"Precision: {prec:.3f}")
    print(f"Recall: {rec:.3f}")
    print(f"F{beta} Score: {fbeta:.3f}")

    ConfusionMatrixDisplay.from_predictions(y_true, y_pred, values_format="d")
    plt.show()


def get_threshold_f_score(
    precision: npt.NDArray,
    recall: npt.NDArray,
    thresholds: npt.NDArray,
    beta: float = 4,
) -> tuple[npt.NDArray, float, float]:
    """Gets the optimal threshold for the Fbeta score, given the precision and recall curves.

    Args:
        beta (float, optional): beta for the Fbeta score. Defaults to 4.

    Returns:
        tuple[npt.NDArray, float, float]: max Fbeta score, threshold
    """
    fbeta_scores = (
        (1 + beta**2) * (precision * recall) / ((beta**2) * precision + recall)
    )
    max_f_score = np.nanmax(fbeta_scores)
    max_f_threshold = thresholds[np.nanargmax(fbeta_scores)]

    return fbeta_scores, float(max_f_score), float(max_f_threshold)


import numpy as np
import plotly.graph_objects as go
from sklearn.metrics import precision_recall_curve


def calculate_fbeta_scores(
    precision: np.ndarray, recall: np.ndarray, beta: float
) -> np.ndarray:
    """
    Calculate F-beta scores with proper handling of edge cases.
    """
    beta_squared = beta**2
    numerator = (1 + beta_squared) * precision * recall
    denominator = (beta_squared * precision) + recall

    # Handle division by zero
    f_scores = np.divide(
        numerator, denominator, out=np.zeros_like(numerator), where=denominator != 0
    )

    return f_scores


def get_threshold_curve(prediction: ModelPrediction, beta: float) -> go.Figure:
    """
    Create threshold optimization curve using actual decision boundaries.
    This is the RECOMMENDED approach.
    """
    fig = go.Figure()

    dataset = prediction.y_true
    preds = prediction.y_pred

    # Get precision, recall, and thresholds at actual decision boundaries
    prec, rec, thresholds = precision_recall_curve(prediction.y_true, prediction.y_pred)

    # CRITICAL: Remove last element to match array lengths
    prec = prec[:-1]
    rec = rec[:-1]

    # Calculate F-beta scores
    f_scores = calculate_fbeta_scores(prec, rec, beta)

    # Plot F-beta score
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=f_scores,
            mode="lines",
            name=f"F{beta} score",
            line={"width": 3},
        )
    )

    # Plot precision
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=prec,
            mode="lines",
            name="Precision",
            line={"width": 2},
        )
    )

    # Plot recall
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=rec,
            mode="lines",
            name="Recall",
            line={"width": 2},
        )
    )

    # Find optimal threshold (handle NaN values)
    valid_scores = ~np.isnan(f_scores)
    if np.any(valid_scores):
        # Replace NaN with -inf so argmax ignores them
        valid_f_scores = np.where(valid_scores, f_scores, -np.inf)
        optimum = np.argmax(valid_f_scores)
        optimal_threshold = thresholds[optimum]
        optimal_f_score = f_scores[optimum]

        print(f"\n{'='*60}")
        print(f"Optimal Threshold for {prediction.population_name}")
        print(f"{'='*60}")
        print(f"Threshold:    {optimal_threshold:.4f}")
        print(f"F{beta} score:     {optimal_f_score:.4f}")
        print(f"Precision:    {prec[optimum]:.4f}")
        print(f"Recall:       {rec[optimum]:.4f}")
        print(f"{'='*60}\n")

        # Add optimal point marker
        fig.add_trace(
            go.Scatter(
                x=[optimal_threshold],
                y=[optimal_f_score],
                mode="markers+text",
                name=f"Optimal (F{beta}={optimal_f_score:.3f})",
                marker={"size": 15, "color": "red", "symbol": "star"},
                text=[f"  Optimal: {optimal_threshold:.3f}"],
                textposition="top right",
            )
        )

        # Add vertical line at optimal threshold
        fig.add_vline(
            x=optimal_threshold,
            line_dash="dash",
            line_color="red",
            opacity=0.5,
            annotation_text=f"Optimal: {optimal_threshold:.3f}",
            annotation_position="top",
        )
    else:
        print(
            f"Warning: No valid F{beta} scores found for {prediction.population_name}"
        )

    # Calculate percentage of positive predictions at each threshold
    positive_cases_nb = np.sum(preds[:, np.newaxis] >= thresholds, axis=0)
    positive_cases_pct = positive_cases_nb / len(dataset)

    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=positive_cases_pct,
            mode="lines",
            name="% Predicted Positive",
            line={"dash": "dash", "width": 2},
            opacity=0.7,
        )
    )

    # Update layout
    fig.update_layout(
        title=f"Threshold Optimization for {prediction.population_name} Dataset (F{beta} Score)",
        xaxis_title="Classification Threshold",
        yaxis_title="Score / Percentage",
        yaxis_tickformat=".0%",
        xaxis=dict(range=[0, 1]),
        yaxis=dict(range=[0, 1]),
        hovermode="x unified",
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="right",
            x=0.99,
            bgcolor="rgba(255, 255, 255, 0.8)",
        ),
        height=600,
    )

    return fig

def get_importance_catboost(model: CatBoostClassifier) -> go.Figure:
    df_importance = pl.DataFrame(
        model.get_feature_importance(prettified=True)
    ).with_columns(pl.col("Importances").round(1))

    fig = px.bar(
        df_importance.to_pandas(),
        x="Importances",
        y="Feature Id",
        orientation="h",
        title="Feature Importances",
    )
    fig.update_layout(yaxis={"categoryorder": "total ascending"})

    return fig


def plot_score_distribution(
    df_plot: pd.DataFrame, scores: np.ndarray, y_true: np.ndarray
):
    """
    Plot the score distribution of the defaulting population vs. non default population

    Args:
        df_plot (pd.DataFrame): _description_
    """

    df_plot["pred_proba"] = scores

    df_plot["y_true"] = y_true

    # Plot the distribution of the score for each country

    _filter_default = df_plot["y_true"] == True
    defaults = df_plot.loc[_filter_default, "pred_proba"].to_numpy()
    non_defaults = df_plot.loc[~_filter_default, "pred_proba"].to_numpy()

    plt.figure(figsize=(10, 6))
    sns.kdeplot(defaults, label="default", color="red", shade=True)
    sns.kdeplot(non_defaults, label="Non-default", color="blue", shade=True)
    plt.title(f"Score Distribution for pred_proba")
    plt.xlabel("Score")
    plt.ylabel("Density")
    plt.legend()
    plt.show()
