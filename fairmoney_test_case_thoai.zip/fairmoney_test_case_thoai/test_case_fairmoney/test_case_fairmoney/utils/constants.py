from pathlib import Path

PATH_PROJECT = Path(__file__).parents[1]
PATH_PROJECT_DATA = Path(__file__).parents[2] / "project_data"

PATH_DATA = PATH_PROJECT_DATA / "data"
PATH_DATA_RAW = PATH_DATA / "raw"
PATH_DATA_COMPRESSED = PATH_DATA / "compressed"
PATH_DATA_PROCESSED = PATH_DATA / "processed"
PATH_DATA_FINAL = PATH_DATA / "final"

PATH_OUTPUT = PATH_PROJECT_DATA / "output"
PATH_MODELS = PATH_PROJECT_DATA / "models"

SEED = 42
