# import scikitplot as skplt
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from sklearn.metrics import roc_auc_score, roc_curve, precision_recall_curve, auc
from plotly.subplots import make_subplots
import numpy as np
    
def plot_score_distribution(
    train_target,
    train_prediction,
    test_target,
    test_prediction,
    val_target,
    val_prediction,
) -> go.Figure:
    """
    Plot score distribution comparing target 1 vs 0 with separate subplots for train, test, and validation sets

    Returns:
        go.Figure: Score distribution subplots
    """

    # Create subplots - 1 row, 3 columns
    fig = make_subplots(
        rows=1,
        cols=3,
        subplot_titles=("Train Set", "Test Set", "Validation Set"),
        shared_yaxes=True,
    )

    # Consistent colors
    color_0 = "skyblue"  # Light blue but still visible
    color_1 = "salmon"  # Light red/pink but still visible

    # TRAIN SET - Column 1
    train_scores_0 = train_prediction[train_target == 0]
    train_scores_1 = train_prediction[train_target == 1]

    fig.add_trace(
        go.Histogram(
            x=train_scores_0,
            name="Target=0",
            opacity=0.7,
            marker_color=color_0,
            nbinsx=30,
            histnorm="probability density",
        ),
        row=1,
        col=1,
    )

    fig.add_trace(
        go.Histogram(
            x=train_scores_1,
            name="Target=1",
            opacity=0.7,
            marker_color=color_1,
            nbinsx=30,
            histnorm="probability density",
        ),
        row=1,
        col=1,
    )

    # TEST SET - Column 2
    test_scores_0 = test_prediction[test_target == 0]
    test_scores_1 = test_prediction[test_target == 1]

    fig.add_trace(
        go.Histogram(
            x=test_scores_0,
            name="Target=0",
            opacity=0.7,
            marker_color=color_0,
            nbinsx=30,
            histnorm="probability density",
            showlegend=False,
        ),
        row=1,
        col=2,
    )

    fig.add_trace(
        go.Histogram(
            x=test_scores_1,
            name="Target=1",
            opacity=0.7,
            marker_color=color_1,
            nbinsx=30,
            histnorm="probability density",
            showlegend=False,
        ),
        row=1,
        col=2,
    )

    # VALIDATION SET - Column 3
    val_scores_0 = val_prediction[val_target == 0]
    val_scores_1 = val_prediction[val_target == 1]

    fig.add_trace(
        go.Histogram(
            x=val_scores_0,
            name="Target=0",
            opacity=0.7,
            marker_color=color_0,
            nbinsx=30,
            histnorm="probability density",
            showlegend=False,
        ),
        row=1,
        col=3,
    )

    fig.add_trace(
        go.Histogram(
            x=val_scores_1,
            name="Target=1",
            opacity=0.7,
            marker_color=color_1,
            nbinsx=30,
            histnorm="probability density",
            showlegend=False,
        ),
        row=1,
        col=3,
    )

    # Update layout
    fig.update_layout(
        title="Score Distribution: Train | Test | Validation",
        barmode="overlay",
        height=500,
        width=1200,
        showlegend=True,
    )

    # Update all x-axes
    fig.update_xaxes(title_text="Predicted Score", row=1, col=1)
    fig.update_xaxes(title_text="Predicted Score", row=1, col=2)
    fig.update_xaxes(title_text="Predicted Score", row=1, col=3)

    # Update y-axis
    fig.update_yaxes(title_text="Density", row=1, col=1)

    return fig
def plot_AUC(
    train_target,
    train_prediction,
    validation_target: None,
    validation_prediction: None,
    test_target,
    test_prediction,
    is_validation:str = True
) -> go.Figure:
    """the plot of AUC curve

    Returns:
        go.Figure: the AUC curve plot
    """
    fpr_train, tpr_train, _ = roc_curve(train_target, train_prediction)
    fpr_test, tpr_test, _ = roc_curve(test_target, test_prediction)

    roc_auc_train = roc_auc_score(train_target, train_prediction)
    roc_auc_test = roc_auc_score(test_target, test_prediction)

    auc_curve = go.Figure()
    auc_curve.add_shape(
        type="line",
        x0=0,
        y0=0,
        x1=1,
        y1=1,
        line={"color": "black", "width": 2, "dash": "dash"},
    )
    if is_validation:
        fpr_validation, tpr_validation, _ = roc_curve(
        validation_target, validation_prediction
    )
        roc_auc_validation = roc_auc_score(validation_target, validation_prediction)

        auc_curve.add_trace(
        go.Scatter(
            x=fpr_validation,
            y=tpr_validation,
            name=f"ROC-Gini Validation {(roc_auc_validation):.2f}",
        )
    )
    auc_curve.add_trace(
        go.Scatter(
            x=fpr_train,
            y=tpr_train,
            name=f"ROC-Gini Train: {(roc_auc_train):.2f}",
        )
    )
    auc_curve.add_trace(
        go.Scatter(
            x=fpr_test,
            y=tpr_test,
            name=f"ROC-Gini Test {(roc_auc_test):.2f}",
        )
    )
    return auc_curve


def plot_PR(train_target, train_prediction, test_target, test_prediction, val_target, val_prediction) -> go.Figure:
    """the function to plot the F1 score

    Returns:
        go.Figure: the F1 score plot
    """
    prec_train, rec_train, _ = precision_recall_curve(train_target, train_prediction)
    pr_auc_train = auc(rec_train, prec_train)

    prec_test, rec_test, _ = precision_recall_curve(test_target, test_prediction)
    pr_auc_test = auc(rec_test, prec_test)
    
    prec_val, rec_val, _ = precision_recall_curve(val_target, val_prediction)
    pr_auc_val = auc(rec_val, prec_val)

    pr_curve = go.Figure()

    pr_curve.add_trace(
        go.Scatter(
            x=rec_train,
            y=prec_train,
            mode="lines",
            name=f"Train PR AUC: {pr_auc_train:.2f}",
            line={"color": "red"},
        )
    )
    pr_curve.add_trace(
        go.Scatter(
            x=rec_test,
            y=prec_test,
            mode="lines",
            name=f"Test PR AUC: {pr_auc_test:.2f}",
            line={"color": "blue"},
        )
    )
    pr_curve.add_trace(
        go.Scatter(
            x=rec_val,
            y=prec_val,
            mode="lines",
            name=f"Validation PR AUC: {pr_auc_val:.2f}",
            line={"color": "green"},
        )
    )
    
    # Optional: Add layout improvements
    # pr_curve.update_layout(
    #     title="Precision-Recall Curves",
    #     xaxis_title="Recall",
    #     yaxis_title="Precision",
    #     legend=dict(x=0.7, y=0.1)
    # )
    
    return pr_curve


# def plot_KS(test_target, test_prediction):
#     """Kolmogorow-Smirnow-Test Visualization

#     Args:
#         figsize (tuple, optional): figsize for plot. Defaults to None.

#     Returns:
#         plt.subplots: K-S plot
#     """
#     return skplt.metrics.plot_ks_statistic(y_true=test_target, y_probas=test_prediction)


def plot_default_rate_over_time(df, cut_off_time, target:str = "inflow_30"):
    """plot of default rate over time

    Returns:
        fig: the plot of default rate over time
    """
    df["label"] = "Test"
    df["label"][df.disbursement_dt < cut_off_time] = "Train"

    df["disbursement_dt"] = df["disbursement_dt"].dt.to_period("M")
    df_plot_ = (
        df.groupby(["label", "disbursement_dt"])[target].mean().reset_index()
    )
    fig = px.line(
        x=df_plot_["disbursement_dt"].astype("str"),
        y=df_plot_[target],
        color=df_plot_["label"],
        markers=True,
    )
    fig.update_layout(
        yaxis_tickformat=".1%",
        yaxis_title="default rate",
        xaxis_title="time",
        title_text="Default rate over time",
    )
    return fig


def plot_default_rate_over_bucket_over_time(df_, bins, prediction):
    df = df_.copy()
    df["bucket"] = pd.cut(
        prediction,
        bins=bins,
        labels=[x for x in range(1, len(bins))],
    )
    df["disbursement_dt"] = df["disbursement_dt"].dt.to_period("M")
    monthly_risk_class = (
        df.groupby(["disbursement_dt", "bucket"])["inflow_15"].mean().reset_index()
    )

    fig = px.line(
        x=monthly_risk_class["disbursement_dt"].astype(str),
        y=monthly_risk_class["inflow_15"],
        color=monthly_risk_class["bucket"],
        markers=True,
    )
    fig.update_layout(
        yaxis_tickformat=".1%",
        xaxis_title="Disbursement_Time",
        yaxis_title="Default_Rate",
    )
    return fig


def plot_distribution_bucket_over_time(df_, bins, prediction):
    df = df_.copy()
    df["bucket"] = pd.cut(
        prediction,
        bins=bins,
        labels=[x for x in range(1, len(bins))],
    )
    df["disbursement_dt"] = df["disbursement_dt"].dt.to_period("M")
    monthly_risk_class = (
        df.groupby(["disbursement_dt", "bucket"])["inflow_15"].size().reset_index()
    )
    monthly_risk_class["percentage"] = monthly_risk_class[
        "inflow_15"
    ] / monthly_risk_class.groupby("disbursement_dt")["inflow_15"].transform("sum")

    fig = px.bar(
        x=monthly_risk_class["disbursement_dt"].astype(str),
        y=monthly_risk_class["percentage"],
        color=monthly_risk_class["bucket"],
    )
    fig.update_layout(
        yaxis_tickformat=".1%",
        xaxis_title="Disbursement_Time",
        yaxis_title="Percentage",
    )
    return fig


def plot_coef(df_coef):
    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            name="avg",
            x=df_coef["features"],
            y=df_coef["avg"],
            error_y=dict(type="data", array=df_coef["std"].to_list()),
        )
    )
    fig.update_layout(
        yaxis_title="value_of_coef",
        xaxis_title="features",
        title_text="Coef of features in logistic regression",
    )
    return fig


def plot_prediction_distribution(df, lr_num, target:str = "inflow_30"):
    df_ploty = df.copy()
    df_ploty["prediction"] = lr_num["prediction"]
    df_ploty[target] = df_ploty[target].astype(object)

    return px.histogram(
        df_ploty,
        x="prediction",
        color=target,
        marginal="box",
    )
def plot_binned_feature_distribution_over_time(df, date_col, binned_feature_col):

    # Group by time period and binned feature
    binned_distribution = (
        df.groupby([date_col, binned_feature_col]).size().unstack(fill_value=0)
    )

    # Normalize to get percentages
    binned_distribution = binned_distribution.div(
        binned_distribution.sum(axis=1), axis=0
    )

    # Plotting
    plt.figure(figsize=(20, 20))
    sns.set(style="whitegrid")

    # Create a stacked area plot
    binned_distribution.plot(
        kind="area", stacked=True, colormap="tab20", alpha=0.8, linewidth=1
    )

    plt.title(
        f"Distribution of {binned_feature_col.capitalize()} Over Time", fontsize=16
    )
    plt.xlabel("Time", fontsize=12)
    plt.ylabel("Proportion", fontsize=12)
    plt.xticks(rotation=90, fontsize=10)
    plt.yticks(fontsize=10)
    plt.legend(
        # title=f"{binned_feature_col.capitalize()}",
        bbox_to_anchor=(1.05, 1),
        loc="upper left",
        fontsize=10,
    )
    plt.tight_layout()
    plt.grid(True, linestyle="--", alpha=0.6)

    # Enhance plot with a horizontal line at y=0.5 for reference
    plt.axhline(0.5, color="grey", linewidth=0.8, linestyle="--", alpha=0.7)

    # Show plot
    plt.show()
def plot_binned_feature_distribution_and_default_rate(
    df, date_col, binned_feature_col, default_col
):
    """
    Create two plots in a single figure:
    1. Distribution of binned feature categories over time (stacked area plot)
    2. Default rate for each binned feature category over time (line plot)

    Parameters:
    -----------
    df : pandas DataFrame
        The dataframe containing the data
    date_col : str
        Column name containing the date/time information
    binned_feature_col : str
        Column name containing the binned/categorical feature
    default_col : str
        Column name containing the default indicator (1 for default, 0 for non-default)

    Returns:
    --------
    fig : matplotlib Figure
        The figure containing both subplots
    """
    import matplotlib.pyplot as plt
    import seaborn as sns

    # Create figure with two subplots (stacked vertically)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 16))
    sns.set(style="whitegrid")

    # PLOT 1: Feature Distribution Over Time (stacked area plot)
    # ---------------------------------------------------------

    # Calculate distribution
    distribution = (
        df.groupby([date_col, binned_feature_col]).size().unstack(fill_value=0)
    )
    distribution = distribution.div(
        distribution.sum(axis=1), axis=0
    )  # Normalize to proportions

    # Plot stacked area chart
    distribution.plot(kind="area", stacked=True, colormap="tab20", alpha=0.8, ax=ax1)

    ax1.set_title(f"Distribution of {binned_feature_col.capitalize()} Over Time")
    ax1.set_ylabel("Proportion")
    ax1.legend(bbox_to_anchor=(1.05, 1), loc="upper left")

    # PLOT 2: Default Rate by Bin Over Time (line plot)
    # ------------------------------------------------

    # Calculate default rate for each bin
    default_rates = (
        df.groupby([date_col, binned_feature_col])[default_col].mean().unstack()
    )

    # Plot line chart
    default_rates.plot(kind="line", marker="o", colormap="tab20", ax=ax2)

    # Add reference line for overall default rate
    overall_rate = df[default_col].mean()
    ax2.axhline(
        overall_rate,
        color="red",
        linestyle="--",
        label=f"Overall Default Rate: {overall_rate:.2%}",
    )

    ax2.set_title(f"Default Rate by {binned_feature_col.capitalize()} Over Time")
    ax2.set_xlabel("Time")
    ax2.set_ylabel("Default Rate")
    ax2.legend(bbox_to_anchor=(1.05, 1), loc="upper left")

    plt.tight_layout()
    return fig