import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any
import json


def extract_credit_features(credit_data: List[Dict]) -> pd.DataFrame:
    """
    Extract features from credit bureau data for PD modeling.
    
    Parameters:
    -----------
    credit_data : List[Dict]
        List of credit bureau records in JSON format
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with extracted features for each application
    """
    
    features_list = []
    
    for record in credit_data:
        app_id = record.get('application_id')
        data = record.get('data', {}).get('consumerfullcredit', {})
        
        features = {'application_id': app_id}
        
        # ============================================================
        # 1. ACCOUNT RATING FEATURES
        # ============================================================
        account_rating = data.get('accountrating', {})
        
        # Basic account counts by status
        features['num_good_accounts'] = int(account_rating.get('noofotheraccountsgood', 0))
        # Description: Total number of accounts in good standing
        # Relevance: Indicates positive credit history and payment reliability
        
        features['num_bad_accounts'] = int(account_rating.get('noofotheraccountsbad', 0))
        # Description: Total number of accounts with negative status
        # Relevance: Direct measure of past payment failures
        
        # Retail accounts
        features['num_retail_good'] = int(account_rating.get('noofretailaccountsgood', 0))
        # Description: Retail accounts (store credit) in good standing
        # Relevance: Shows consumer spending behavior
        
        features['num_retail_bad'] = int(account_rating.get('noofretailaccountsbad', 0))
        # Description: Retail accounts with issues
        # Relevance: Retail payment behavior indicator
        
        # Personal loan accounts
        features['num_personal_loan_good'] = int(account_rating.get('noofpersonalloanaccountsgood', 0))
        # Description: Personal loans in good standing
        # Relevance: Performance on similar loan products
        
        features['num_personal_loan_bad'] = int(account_rating.get('noofpersonalloanaccountsbad', 0))
        # Description: Personal loans with issues
        # Relevance: Risk indicator for personal lending
        
        # Credit card accounts
        features['num_credit_card_good'] = int(account_rating.get('noofcreditcardaccountsgood', 0))
        # Description: Credit cards in good standing
        # Relevance: Revolving credit management ability
        
        features['num_credit_card_bad'] = int(account_rating.get('noofcreditcardaccountsbad', 0))
        # Description: Credit cards with issues
        # Relevance: Credit card payment behavior
        
        # Telecom accounts
        features['num_telecom_good'] = int(account_rating.get('nooftelecomaccountsgood', 0))
        # Description: Telecom accounts (phone bills) in good standing
        # Relevance: Utility payment discipline
        
        features['num_telecom_bad'] = int(account_rating.get('nooftelecomaccountsbad', 0))
        # Description: Telecom accounts with issues
        # Relevance: Recurring payment reliability
        
        # Auto loan accounts
        features['num_auto_loan_good'] = int(account_rating.get('noofautoloanccountsgood', 0))
        # Description: Auto loans in good standing
        # Relevance: Secured loan performance
        
        features['num_auto_loan_bad'] = int(account_rating.get('noofautoloanaccountsbad', 0))
        # Description: Auto loans with issues
        # Relevance: Asset-backed credit behavior
        
        # Home loan accounts
        features['num_home_loan_good'] = int(account_rating.get('noofhomeloanaccountsgood', 0))
        # Description: Home/mortgage loans in good standing
        # Relevance: Long-term credit commitment performance
        
        features['num_home_loan_bad'] = int(account_rating.get('noofhomeloanaccountsbad', 0))
        # Description: Home/mortgage loans with issues
        # Relevance: Major loan payment behavior
        
        # Joint loan accounts
        features['num_joint_loan_good'] = int(account_rating.get('noofjointloanaccountsgood', 0))
        # Description: Joint loans in good standing
        # Relevance: Shared responsibility credit performance
        
        features['num_joint_loan_bad'] = int(account_rating.get('noofjointloanaccountsbad', 0))
        # Description: Joint loans with issues
        # Relevance: Co-borrowing payment behavior
        
        # Study loan accounts
        features['num_study_loan_good'] = int(account_rating.get('noofstudyloanaccountsgood', 0))
        # Description: Education loans in good standing
        # Relevance: Long-term loan payment patterns
        
        features['num_study_loan_bad'] = int(account_rating.get('noofstudyloanaccountsbad', 0))
        # Description: Education loans with issues
        # Relevance: Student loan payment behavior
        
        # Derived ratios
        total_accounts = features['num_good_accounts'] + features['num_bad_accounts']
        features['bad_account_ratio'] = (
            features['num_bad_accounts'] / total_accounts if total_accounts > 0 else 0
        )
        # Description: Proportion of bad accounts to total accounts
        # Relevance: Normalized credit quality measure
        
        total_retail = features['num_retail_good'] + features['num_retail_bad']
        features['retail_bad_ratio'] = (
            features['num_retail_bad'] / total_retail if total_retail > 0 else 0
        )
        # Description: Proportion of retail accounts that are bad
        # Relevance: Retail credit quality
        
        total_personal_loan = features['num_personal_loan_good'] + features['num_personal_loan_bad']
        features['personal_loan_bad_ratio'] = (
            features['num_personal_loan_bad'] / total_personal_loan if total_personal_loan > 0 else 0
        )
        # Description: Proportion of personal loans that are bad
        # Relevance: Personal loan credit quality
        
        total_credit_card = features['num_credit_card_good'] + features['num_credit_card_bad']
        features['credit_card_bad_ratio'] = (
            features['num_credit_card_bad'] / total_credit_card if total_credit_card > 0 else 0
        )
        # Description: Proportion of credit cards that are bad
        # Relevance: Credit card portfolio quality
        
        features['total_secured_loans'] = (
            features['num_auto_loan_good'] + features['num_auto_loan_bad'] +
            features['num_home_loan_good'] + features['num_home_loan_bad']
        )
        # Description: Total secured loan accounts (auto + home)
        # Relevance: Asset-backed credit exposure
        
        features['total_unsecured_loans'] = (
            features['num_personal_loan_good'] + features['num_personal_loan_bad'] +
            features['num_credit_card_good'] + features['num_credit_card_bad']
        )
        # Description: Total unsecured loan accounts
        # Relevance: Unsecured credit exposure
        
        features['has_home_loan'] = int(
            (features['num_home_loan_good'] + features['num_home_loan_bad']) > 0
        )
        # Description: Has any home loan
        # Relevance: Homeownership indicator
        
        features['secured_to_unsecured_ratio'] = (
            features['total_secured_loans'] / (features['total_unsecured_loans'] + 1)
        )
        # Description: Ratio of secured to unsecured loans
        # Relevance: Credit portfolio composition
        
        features['good_to_bad_ratio'] = (
            features['num_good_accounts'] / (features['num_bad_accounts'] + 1)
        )
        # Description: Ratio of good to bad accounts
        # Relevance: Overall credit quality measure
        
        features['num_product_types'] = sum([
            1 if features['num_retail_good'] + features['num_retail_bad'] > 0 else 0,
            1 if features['num_personal_loan_good'] + features['num_personal_loan_bad'] > 0 else 0,
            1 if features['num_credit_card_good'] + features['num_credit_card_bad'] > 0 else 0,
            1 if features['num_auto_loan_good'] + features['num_auto_loan_bad'] > 0 else 0,
            1 if features['num_home_loan_good'] + features['num_home_loan_bad'] > 0 else 0,
            1 if features['num_telecom_good'] + features['num_telecom_bad'] > 0 else 0,
        ])
        # Description: Number of different credit product types used
        # Relevance: Credit portfolio diversity
        
        features['personal_loan_concentration'] = (
            (features['num_personal_loan_good'] + features['num_personal_loan_bad']) / 
            (total_accounts + 1)
        )
        # Description: Proportion of accounts that are personal loans
        # Relevance: Credit concentration measure
        
        # ============================================================
        # 2. CREDIT ACCOUNT SUMMARY FEATURES
        # ============================================================
        credit_summary = data.get('creditaccountsummary', {})
        
        features['credit_rating'] = float(credit_summary.get('rating', 0))
        # Description: Bureau's composite credit rating score
        # Relevance: Overall creditworthiness indicator
        
        features['amount_in_arrears'] = float((credit_summary.get('amountarrear') or '0').replace(',', ''))
        # Description: Total amount currently overdue
        # Relevance: Current payment stress measure
        
        features['amount_in_arrears_1'] = float((credit_summary.get('amountarrear1') or '0').replace(',', ''))
        # Description: Alternative arrears amount metric
        # Relevance: Secondary arrears measure
        
        features['total_accounts'] = int(credit_summary.get('totalaccounts', 0))
        # Description: Total number of credit accounts
        # Relevance: Credit experience breadth
        
        features['total_accounts_1'] = int(credit_summary.get('totalaccounts1', 0))
        # Description: Alternative account count metric
        # Relevance: Secondary account count
        
        features['total_accounts_in_arrears'] = int(credit_summary.get('totalaccountarrear', 0))
        # Description: Number of accounts currently in arrears
        # Relevance: Breadth of payment difficulties
        
        features['total_accounts_in_arrears_1'] = int(credit_summary.get('totalaccountarrear1', 0))
        # Description: Alternative accounts in arrears metric
        # Relevance: Secondary arrears count
        
        features['total_outstanding_debt'] = float(
            (credit_summary.get('totaloutstandingdebt') or '0').replace(',', '')
        )
        # Description: Total current debt across all accounts
        # Relevance: Overall debt burden
        
        features['total_outstanding_debt_1'] = float(
            (credit_summary.get('totaloutstandingdebt1') or '0').replace(',', '')
        )
        # Description: Alternative outstanding debt metric
        # Relevance: Secondary debt measure
        
        features['total_monthly_instalment'] = float(
            (credit_summary.get('totalmonthlyinstalment') or '0').replace(',', '')
        )
        # Description: Total monthly payment obligations
        # Relevance: Monthly payment burden
        
        features['total_monthly_instalment_1'] = float(
            (credit_summary.get('totalmonthlyinstalment1') or '0').replace(',', '')
        )
        # Description: Alternative monthly instalment metric
        # Relevance: Secondary payment obligation measure
        
        features['num_judgements'] = int(credit_summary.get('totalnumberofjudgement', 0))
        # Description: Number of legal judgements
        # Relevance: Legal action indicator
        
        features['num_judgements_1'] = int(credit_summary.get('totalnumberofjudgement1', 0))
        # Description: Alternative judgement count metric
        # Relevance: Secondary legal judgement measure
        
        features['judgement_amount'] = float(credit_summary.get('totaljudgementamount', 0))
        # Description: Total amount of legal judgements
        # Relevance: Legal issue severity
        
        features['judgement_amount_1'] = float(credit_summary.get('totaljudgementamount1', 0))
        # Description: Alternative judgement amount metric
        # Relevance: Secondary legal amount measure
        
        last_judgement = credit_summary.get('lastjudgementdate', '-')
        if last_judgement and last_judgement != '-':
            try:
                judgement_date = datetime.strptime(last_judgement, '%d/%m/%Y')
                features['days_since_last_judgement'] = (datetime.now() - judgement_date).days
            except:
                features['days_since_last_judgement'] = 9999
        else:
            features['days_since_last_judgement'] = 9999
        # Description: Days since most recent judgement
        # Relevance: Recency of legal issues
        
        features['dishonoured_count'] = int(credit_summary.get('totalnumberofdishonoured', 0))
        # Description: Number of dishonoured payments
        # Relevance: Payment failure frequency
        
        features['dishonoured_count_1'] = int(credit_summary.get('totalnumberofdishonoured1', 0))
        # Description: Alternative dishonoured count metric
        # Relevance: Secondary payment failure measure
        
        features['dishonoured_amount'] = float(
            (credit_summary.get('totaldishonouredamount') or '0').replace(',', '')
        )
        # Description: Total amount of dishonoured payments
        # Relevance: Payment failure severity
        
        features['dishonoured_amount_1'] = float(
            (credit_summary.get('totaldishonouredamount1') or '0').replace(',', '')
        )
        # Description: Alternative dishonoured amount metric
        # Relevance: Secondary payment failure amount
        
        features['accounts_in_overdraft'] = int(credit_summary.get('totalaccountingodcondition', 0))
        # Description: Number of accounts in overdraft
        # Relevance: Liquidity stress indicator
        
        features['accounts_in_overdraft_1'] = int(credit_summary.get('totalaccountingodcondition1', 0))
        # Description: Alternative overdraft count metric
        # Relevance: Secondary overdraft measure
        
        # Derived ratios
        features['arrears_ratio'] = (
            features['total_accounts_in_arrears'] / features['total_accounts'] 
            if features['total_accounts'] > 0 else 0
        )
        # Description: Proportion of accounts in arrears
        # Relevance: Normalized delinquency measure
        
        features['arrears_ratio_1'] = (
            features['total_accounts_in_arrears_1'] / features['total_accounts_1'] 
            if features['total_accounts_1'] > 0 else 0
        )
        # Description: Alternative proportion of accounts in arrears
        # Relevance: Secondary normalized delinquency
        
        features['debt_to_instalment_ratio'] = (
            features['total_outstanding_debt'] / features['total_monthly_instalment']
            if features['total_monthly_instalment'] > 0 else 0
        )
        # Description: Debt to monthly payment ratio
        # Relevance: Debt sustainability measure
        
        features['arrears_to_debt_ratio'] = (
            features['amount_in_arrears'] / features['total_outstanding_debt']
            if features['total_outstanding_debt'] > 0 else 0
        )
        # Description: Proportion of debt that is overdue
        # Relevance: Current payment problem severity
        
        features['overdraft_ratio'] = (
            features['accounts_in_overdraft'] / features['total_accounts']
            if features['total_accounts'] > 0 else 0
        )
        # Description: Proportion of accounts in overdraft
        # Relevance: Liquidity stress measure
        
        features['has_recent_judgement'] = int(features['days_since_last_judgement'] < 365)
        # Description: Had judgement in last 12 months
        # Relevance: Recent legal issue indicator
        
        features['has_multiple_severe_issues'] = int(
            (features['num_judgements'] > 0) +
            (features['total_accounts_in_arrears'] > 1) +
            (features['dishonoured_count'] > 2) +
            (features['accounts_in_overdraft'] > 0) >= 2
        )
        # Description: Has 2 or more severe credit issues
        # Relevance: Multiple problem indicator
        
        # ============================================================
        # 3. DELINQUENCY INFORMATION
        # ============================================================
        delinquency = data.get('deliquencyinformation', {})
        
        features['max_months_in_arrears'] = int(delinquency.get('monthsinarrears', 0))
        # Description: Maximum months any account has been in arrears
        # Relevance: Worst delinquency severity
        
        if delinquency.get('periodnum'):
            try:
                period_str = str(delinquency.get('periodnum'))
                if len(period_str) == 8:
                    delinq_date = datetime.strptime(period_str, '%Y%m%d')
                    features['days_since_worst_delinquency'] = (datetime.now() - delinq_date).days
                else:
                    features['days_since_worst_delinquency'] = 9999
            except:
                features['days_since_worst_delinquency'] = 9999
        else:
            features['days_since_worst_delinquency'] = 9999
        # Description: Days since the worst delinquency period
        # Relevance: Recency of worst payment failure
        
        # ============================================================
        # 4. CREDIT AGREEMENT DETAILS
        # ============================================================
        credit_agreements = data.get('creditagreementsummary', [])
        
        features['num_active_accounts'] = sum(
            1 for acc in credit_agreements 
            if (acc.get('accountstatus') or '').lower() in ['open', 'performing']
        )
        # Description: Number of currently active/open accounts
        # Relevance: Current credit exposure
        
        features['num_closed_accounts'] = sum(
            1 for acc in credit_agreements 
            if (acc.get('accountstatus') or '').lower() in ['closed', 'paid up']
        )
        # Description: Number of successfully closed accounts
        # Relevance: Past credit management success
        
        features['num_written_off_accounts'] = sum(
            1 for acc in credit_agreements 
            if 'written' in (acc.get('accountstatus') or '').lower()
        )
        # Description: Number of accounts written off by lenders
        # Relevance: Severe default indicator
        
        features['num_null_status_accounts'] = sum(
            1 for acc in credit_agreements 
            if not acc.get('accountstatus')
        )
        # Description: Number of accounts with missing status
        # Relevance: Data quality indicator
        
        features['num_performing_accounts'] = sum(
            1 for acc in credit_agreements 
            if (acc.get('performancestatus') or '').lower() == 'performing'
        )
        # Description: Number of accounts with performing status
        # Relevance: Current payment behavior
        
        features['num_lost_accounts'] = sum(
            1 for acc in credit_agreements 
            if (acc.get('performancestatus') or '').lower() == 'lost'
        )
        # Description: Number of accounts marked as lost/defaulted
        # Relevance: Direct default indicator
        
        # Financial aggregates
        total_current_balance = 0
        total_overdue = 0
        total_opening_balance = 0
        total_instalment = 0
        
        for acc in credit_agreements:
            try:
                balance = float((acc.get('currentbalanceamt') or '0').replace(',', ''))
                total_current_balance += balance
                
                overdue = float((acc.get('amountoverdue') or '0').replace(',', ''))
                total_overdue += overdue
                
                opening = float((acc.get('openingbalanceamt') or '0').replace(',', ''))
                total_opening_balance += opening
                
                instalment = float((acc.get('instalmentamount') or '0').replace(',', ''))
                total_instalment += instalment
            except:
                continue
        
        features['total_current_balance'] = total_current_balance
        # Description: Sum of current balances across all accounts
        # Relevance: Total debt exposure
        
        features['total_amount_overdue'] = total_overdue
        # Description: Total overdue amount across all accounts
        # Relevance: Current payment stress
        
        features['total_opening_balance'] = total_opening_balance
        # Description: Sum of original loan amounts
        # Relevance: Historical credit access
        
        features['total_instalment_amount'] = total_instalment
        # Description: Sum of all monthly instalments
        # Relevance: Total monthly payment burden
        
        # Loan duration features
        loan_durations = []
        for acc in credit_agreements:
            duration = acc.get('loanduration')
            if duration and str(duration) != '0':
                try:
                    loan_durations.append(float(duration))
                except:
                    continue
        
        features['avg_loan_duration_days'] = np.mean(loan_durations) if loan_durations else 0
        # Description: Average loan duration in days
        # Relevance: Loan term preference
        
        features['max_loan_duration_days'] = max(loan_durations) if loan_durations else 0
        # Description: Longest loan duration
        # Relevance: Long-term credit experience
        
        features['min_loan_duration_days'] = min(loan_durations) if loan_durations else 0
        # Description: Shortest loan duration
        # Relevance: Short-term credit usage
        
        # Account age features
        account_ages = []
        for acc in credit_agreements:
            try:
                opened = datetime.strptime(acc.get('dateaccountopened', '01/01/2020'), '%d/%m/%Y')
                account_ages.append((datetime.now() - opened).days)
            except:
                continue
        
        features['avg_account_age_days'] = np.mean(account_ages) if account_ages else 0
        # Description: Average age of credit accounts in days
        # Relevance: Credit history depth
        
        features['oldest_account_age_days'] = max(account_ages) if account_ages else 0
        # Description: Age of oldest credit account in days
        # Relevance: Length of credit history
        
        features['newest_account_age_days'] = min(account_ages) if account_ages else 0
        # Description: Age of newest credit account
        # Relevance: Recent credit activity
        
        # ============================================================
        # 5. ENQUIRY HISTORY FEATURES
        # ============================================================
        enquiries = data.get('enquiryhistorytop', [])
        
        enquiry_dates = []
        for enq in enquiries:
            try:
                date_str = (enq.get('daterequested') or '').split()[0]
                enq_date = datetime.strptime(date_str, '%d/%m/%Y')
                days_ago = (datetime.now() - enq_date).days
                enquiry_dates.append(days_ago)
            except:
                continue
        
        features['num_enquiries_last_30_days'] = sum(1 for d in enquiry_dates if d <= 30)
        # Description: Enquiries in last 30 days
        # Relevance: Very recent credit seeking
        
        features['num_enquiries_last_90_days'] = sum(1 for d in enquiry_dates if d <= 90)
        # Description: Enquiries in last 90 days
        # Relevance: Recent credit seeking behavior
        
        features['days_since_last_enquiry'] = min(enquiry_dates) if enquiry_dates else 9999
        # Description: Days since most recent credit enquiry
        # Relevance: Recency of credit application
        
        features['excessive_enquiries'] = int(features['num_enquiries_last_90_days'] > 5)
        # Description: More than 5 enquiries in last 90 days
        # Relevance: Excessive credit shopping indicator
        
        enquiry_lenders = [(enq.get('subscribername') or '') for enq in enquiries]
        features['num_unique_enquiry_lenders'] = len(set(enquiry_lenders))
        # Description: Number of different lenders queried
        # Relevance: Lender diversity in applications
        
        enquiry_reasons = [enq.get('enquiryreason', '') for enq in enquiries]
        features['num_credit_scoring_enquiries'] = sum(
            1 for reason in enquiry_reasons if 'scoring' in reason.lower()
        )
        # Description: Number of credit scoring enquiries
        # Relevance: Credit assessment activity
        
        features['num_application_enquiries'] = sum(
            1 for reason in enquiry_reasons if 'application' in reason.lower()
        )
        # Description: Number of new credit application enquiries
        # Relevance: Active credit application behavior
        
        if len(enquiry_dates) >= 2:
            sorted_dates = sorted(enquiry_dates)
            time_gaps = [sorted_dates[i+1] - sorted_dates[i] for i in range(len(sorted_dates)-1)]
            features['avg_days_between_enquiries'] = np.mean(time_gaps) if time_gaps else 0
        else:
            features['avg_days_between_enquiries'] = 0
        # Description: Average days between consecutive enquiries
        # Relevance: Enquiry frequency pattern
        
        enquiry_clusters = 0
        if len(enquiry_dates) >= 2:
            sorted_dates = sorted(enquiry_dates)
            for i in range(len(sorted_dates) - 1):
                if abs(sorted_dates[i] - sorted_dates[i+1]) <= 7:
                    enquiry_clusters += 1
        features['num_enquiry_clusters'] = enquiry_clusters
        # Description: Number of enquiry pairs within 7 days
        # Relevance: Burst enquiry pattern
        
        # ============================================================
        # 6. PAYMENT HISTORY FEATURES
        # ============================================================
        payment_history = data.get('accountmonthlypaymenthistory', [])
        
        all_payment_codes = []
        recent_6m_codes = []
        recent_3m_codes = []
        
        for acc in payment_history:
            for i in range(1, 25):
                code = acc.get(f'm{i:02d}', '#')
                if code != '#':
                    all_payment_codes.append(code)
            
            for i in range(1, 7):
                code = acc.get(f'm{i:02d}', '#')
                if code != '#':
                    recent_6m_codes.append(code)
            
            for i in range(1, 4):
                code = acc.get(f'm{i:02d}', '#')
                if code != '#':
                    recent_3m_codes.append(code)
        
        numeric_codes = [int(c) if c.isdigit() else None for c in all_payment_codes]
        numeric_codes = [c for c in numeric_codes if c is not None]
        
        recent_6m_numeric = [int(c) if c.isdigit() else None for c in recent_6m_codes]
        recent_6m_numeric = [c for c in recent_6m_numeric if c is not None]
        
        recent_3m_numeric = [int(c) if c.isdigit() else None for c in recent_3m_codes]
        recent_3m_numeric = [c for c in recent_3m_numeric if c is not None]
        
        features['num_payment_records'] = len(all_payment_codes)
        # Description: Total number of monthly payment records
        # Relevance: Credit history depth
        
        on_time_payments = sum(1 for c in all_payment_codes if c == '0')
        features['on_time_payment_ratio'] = (
            on_time_payments / features['num_payment_records'] 
            if features['num_payment_records'] > 0 else 0
        )
        # Description: Proportion of on-time payments
        # Relevance: Payment discipline measure
        
        recent_6m_ontime = sum(1 for c in recent_6m_codes if c == '0')
        features['on_time_ratio_6m'] = (
            recent_6m_ontime / len(recent_6m_codes) 
            if recent_6m_codes else 0
        )
        # Description: Recent 6-month on-time payment rate
        # Relevance: Recent payment behavior
        
        features['max_dpd_ever'] = max(numeric_codes) if numeric_codes else 0
        # Description: Worst delinquency ever recorded (days past due)
        # Relevance: Historical payment failure severity
        
        features['max_dpd_6m'] = max(recent_6m_numeric) if recent_6m_numeric else 0
        # Description: Worst delinquency in last 6 months
        # Relevance: Recent payment failure severity
        
        features['max_dpd_3m'] = max(recent_3m_numeric) if recent_3m_numeric else 0
        # Description: Worst delinquency in last 3 months
        # Relevance: Very recent payment behavior
        
        features['num_times_30plus_late'] = sum(1 for c in numeric_codes if c >= 30)
        # Description: Count of 30+ days past due occurrences
        # Relevance: Frequency of serious delinquency
        
        features['num_times_30plus_late_6m'] = sum(1 for c in recent_6m_numeric if c >= 30)
        # Description: Count of 30+ DPD in recent 6 months
        # Relevance: Recent serious delinquency frequency
        
        features['ever_90plus_dpd'] = int(any(c >= 90 for c in numeric_codes))
        # Description: Has ever been 90+ days delinquent
        # Relevance: Severe delinquency indicator
        
        max_consecutive_late = 0
        current_consecutive = 0
        for code in all_payment_codes:
            if code != '0' and code != '#':
                current_consecutive += 1
                max_consecutive_late = max(max_consecutive_late, current_consecutive)
            else:
                current_consecutive = 0
        features['max_consecutive_late'] = max_consecutive_late
        # Description: Longest streak of consecutive late payments
        # Relevance: Sustained delinquency pattern
        
        current_late_streak = 0
        for acc in payment_history:
            for i in range(1, 7):
                code = acc.get(f'm{i:02d}', '#')
                if code != '0' and code != '#' and code.isdigit() and int(code) > 0:
                    current_late_streak += 1
                else:
                    break
        features['current_late_streak'] = current_late_streak
        # Description: Ongoing consecutive late payments from most recent month
        # Relevance: Active delinquency indicator
        
        older_codes = []
        for acc in payment_history:
            for i in range(7, 13):
                code = acc.get(f'm{i:02d}', '#')
                if code != '#' and code.isdigit():
                    older_codes.append(int(code))
        
        avg_recent = np.mean(recent_3m_numeric) if recent_3m_numeric else 0
        avg_older = np.mean(older_codes) if older_codes else 0
        features['payment_trend_deteriorating'] = int(avg_recent > avg_older)
        # Description: Payment behavior worsening vs improving
        # Relevance: Payment trend direction
        
        features['avg_dpd_6m'] = np.mean(recent_6m_numeric) if recent_6m_numeric else 0
        # Description: Average days past due in recent 6 months
        # Relevance: Recent payment quality
        
        features['payment_volatility_6m'] = (
            np.std(recent_6m_numeric) if len(recent_6m_numeric) > 1 else 0
        )
        # Description: Standard deviation of recent payment codes
        # Relevance: Payment behavior consistency
        
        features['has_payment_history'] = int(len(all_payment_codes) > 0)
        # Description: Has any payment history reported
        # Relevance: Credit file completeness
        
        # ============================================================
        # 7. DEMOGRAPHIC FEATURES
        # ============================================================
        personal_details = data.get('personaldetailssummary', {})
        
        features['gender'] = 1 if (personal_details.get('gender') or '').lower() == 'male' else 0
        # Description: Gender (1=Male, 0=Female)
        # Relevance: Demographic characteristic
        
        try:
            birthdate = datetime.strptime(
                personal_details.get('birthdate', '01/01/1900'), 
                '%d/%m/%Y'
            )
            features['age'] = (datetime.now() - birthdate).days // 365
        except:
            features['age'] = 0
        # Description: Age in years
        # Relevance: Life stage indicator
        
        try:
            features['num_dependants'] = int(personal_details.get('dependants', 0))
        except:
            features['num_dependants'] = 0
        # Description: Number of dependants
        # Relevance: Financial burden indicator
        
        features['has_bvn'] = int(bool(personal_details.get('bankverificationno')))
        # Description: Has Bank Verification Number
        # Relevance: Identity verification status
        
        features['has_email'] = int(bool(personal_details.get('emailaddress')))
        # Description: Has email address on file
        # Relevance: Contact information completeness
        
        features['has_employer'] = int(bool(personal_details.get('employerdetail')))
        # Description: Has employer information
        # Relevance: Employment status indicator
        
        features['has_property_info'] = int(bool(personal_details.get('propertyownedtype')))
        # Description: Has property ownership information
        # Relevance: Asset ownership indicator
        
        features['is_nigerian'] = int(
            personal_details.get('nationality', '').lower() == 'nigeria'
        )
        # Description: Nigerian nationality
        # Relevance: Nationality indicator
        
        # ============================================================
        # 8. EMPLOYMENT HISTORY FEATURES
        # ============================================================
        employment_history = data.get('employmenthistory', [])
        
        features['num_employment_records'] = len(employment_history)
        # Description: Number of employment history entries
        # Relevance: Employment data availability
        
        recent_update = False
        for emp in employment_history:
            update_date = emp.get('updatedate') or emp.get('updateondate')
            if update_date:
                try:
                    update_dt = datetime.strptime(update_date, '%d/%m/%Y')
                    days_since_update = (datetime.now() - update_dt).days
                    if days_since_update <= 365:
                        recent_update = True
                        break
                except:
                    continue
        features['has_recent_employment_update'] = int(recent_update)
        # Description: Employment info updated in last 12 months
        # Relevance: Data recency indicator
        
        max_days_since_update = 9999
        for emp in employment_history:
            update_date = emp.get('updatedate') or emp.get('updateondate')
            if update_date:
                try:
                    update_dt = datetime.strptime(update_date, '%d/%m/%Y')
                    days = (datetime.now() - update_dt).days
                    max_days_since_update = min(max_days_since_update, days)
                except:
                    continue
        features['days_since_employment_update'] = max_days_since_update
        # Description: Days since most recent employment update
        # Relevance: Employment data freshness
        
        # ============================================================
        # 9. DERIVED RISK INDICATORS
        # ============================================================
        
        features['has_any_default_indicator'] = int(
            features['num_bad_accounts'] > 0 or
            features['num_written_off_accounts'] > 0 or
            features['num_lost_accounts'] > 0 or
            features['max_months_in_arrears'] > 3
        )
        # Description: Has any major default indicator
        # Relevance: Composite default flag
        
        features_list.append(features)
    
    return pd.DataFrame(features_list)
