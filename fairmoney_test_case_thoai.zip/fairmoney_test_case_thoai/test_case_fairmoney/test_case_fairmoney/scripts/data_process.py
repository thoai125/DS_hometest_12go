from dataclasses import asdict, dataclass, fields
from functools import lru_cache
from pathlib import Path
from typing import Callable

import pandas as pd
import polars as pl
import pyarrow.parquet as pq
from snowflake.connector import connect
from snowflake.connector.connection import SnowflakeConnection
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from test_case_fairmoney.utils.constants import PATH_DATA_COMPRESSED, PATH_DATA_RAW
from test_case_fairmoney.utils.settings import get_settings


@dataclass
class ProjectDataInput:
    path_sql: Path | None = None
    path_csv: Path | None = None
    fn_input: Callable | None = (
        None  # in case of complex operations, you can use a function
    )
    params_sql: dict | None = None  # in case you use a SQL file with parameters


@dataclass
class ProjectDataOutput:
    path_parquet: Path | None = None
    path_csv: Path | None = None
    sql_table: str | None = None  # output SQL table, make sure it it's in lowercase!


@dataclass
class ProjectDataFile:
    project_input: ProjectDataInput
    project_output: ProjectDataOutput


@dataclass
class ProjectData:
    file_from_sql: ProjectDataFile
    file_from_csv: ProjectDataFile


def get_project_data() -> ProjectData:
    return ProjectData(
        file_from_sql=ProjectDataFile(
            project_input=ProjectDataInput(
                path_sql=PATH_DATA_RAW / "sql_file.sql",
                params_sql={"value": 1},
            ),
            project_output=ProjectDataOutput(
                path_parquet=PATH_DATA_COMPRESSED / "sql_file.parquet",
            ),
        ),
        file_from_csv=ProjectDataFile(
            project_input=ProjectDataInput(
                path_csv=PATH_DATA_RAW / "csv_file.csv",
            ),
            project_output=ProjectDataOutput(
                path_parquet=PATH_DATA_COMPRESSED / "csv_file.parquet",
                sql_table="sandbox.quantitative_risk.csv_file",
            ),
        ),
    )


def _credentials(db: str) -> dict:
    settings = get_settings()

    return {
        "user": settings.SNOWFLAKE_USER,
        "account": settings.SNOWFLAKE_ACCOUNT,
        "warehouse": settings.SNOWFLAKE_WAREHOUSE,
        "role": settings.SNOWFLAKE_ROLE,
        "database": db,
    }


def _url(db="RAW") -> str:
    creds = _credentials(db)
    return (
        f"snowflake://{creds['user']}@{creds['account']}/{creds['database']}"
        + f"?warehouse={creds['warehouse']}&role={creds['role']}"
    )


@lru_cache
def get_engine(db="RAW") -> Engine:
    url = _url(db)
    engine = create_engine(url, connect_args={"authenticator": "externalbrowser"})
    assert isinstance(engine, Engine)

    return engine


@lru_cache
def get_connection(db="RAW") -> SnowflakeConnection:
    creds = _credentials(db)
    conn = connect(
        user=creds["user"],
        account=creds["account"],
        database=creds["database"],
        role=creds["role"],
        authenticator="externalbrowser",
    )

    return conn


def get_sql_query(path: Path) -> str:
    with Path.open(path, "r") as f:
        return f.read()


def get_sql_data(project_input: ProjectDataInput) -> pl.DataFrame:
    assert project_input.path_sql is not None
    sql = get_sql_query(project_input.path_sql)
    conn = get_connection()
    cur = conn.cursor()

    dict_params = project_input.params_sql or {}
    cur.execute(sql, params=dict_params)

    # read in batches to avoid missing read
    batches = cur.get_result_batches()
    assert batches is not None

    for result in batches:
        ar = result.to_arrow()
        pq.write_to_dataset(ar, PATH_DATA_COMPRESSED / "tmp")

    files = list((PATH_DATA_COMPRESSED / "tmp").glob("*.parquet"))
    df = pl.read_parquet(files)

    # remove temporary files
    for f in files:
        f.unlink()

    _ = (PATH_DATA_COMPRESSED / "tmp").rmdir()

    return df


def generate_input_fn(project_input: ProjectDataInput) -> pl.DataFrame:
    fn_execute = project_input.fn_input
    assert fn_execute is not None
    return fn_execute()


def generate_input_path(project_input: ProjectDataInput) -> pl.DataFrame:
    if project_input.path_sql is not None:
        df = get_sql_data(project_input)
    elif project_input.path_csv is not None:
        df = pl.from_pandas(pd.read_csv(project_input.path_csv))
    else:
        raise ValueError("No input received")

    return df


def generate_input(project_input: ProjectDataInput) -> pl.DataFrame:
    df = pl.DataFrame()
    if project_input.fn_input is not None:
        df = generate_input_fn(project_input)
    else:
        df = generate_input_path(project_input)

    # convert column names to lowercase
    # columns can often be put in uppercase by snowflake
    df.columns = [c.lower() for c in df.columns]

    return df


def generate_output(project_output: ProjectDataOutput, df: pl.DataFrame) -> None:
    if project_output.path_parquet is not None:
        df.write_parquet(project_output.path_parquet)

    if project_output.path_csv is not None:
        df.write_csv(project_output.path_csv)


def generate_output_sql_table(
    project_output: ProjectDataOutput, df: pl.DataFrame
) -> None:
    if project_output.sql_table is not None:
        db = project_output.sql_table.split(".")[0]
        name = project_output.sql_table.split(".")[-1]
        schema = ".".join(project_output.sql_table.split(".")[1:-1])
        engine = get_engine(db=db)

        df.to_pandas().to_sql(
            name=name, con=engine, schema=schema, index=False, if_exists="replace"
        )


def should_regenerate(project_output: ProjectDataOutput, force: bool) -> bool:
    # sql table should always be regenerated
    if project_output.sql_table is not None:
        return True

    # output files already exist and force is False
    if not force and all(
        value is None or value.exists()
        for key, value in asdict(project_output).items()
        if key != "sql_table"
    ):
        return False

    return True


def generate_data(project_data: ProjectData, force=False) -> None:
    for field in fields(project_data):
        project_data_file: ProjectDataFile = getattr(project_data, field.name)

        # no queries to execute
        # this checks if every property of the input is None
        if all(
            value is None for value in asdict(project_data_file.project_input).values()
        ):
            continue

        if not should_regenerate(project_data_file.project_output, force):
            continue

        df = generate_input(project_data_file.project_input)
        generate_output(project_data_file.project_output, df)
        generate_output_sql_table(project_data_file.project_output, df)


if __name__ == "__main__":
    project_data = get_project_data()
    generate_data(project_data, force=True)
