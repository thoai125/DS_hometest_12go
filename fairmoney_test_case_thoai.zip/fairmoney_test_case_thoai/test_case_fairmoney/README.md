# Credit Risk Modeling - FairMoney Test Case

[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)
[![Linting - Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Code style - Black](https://img.shields.io/badge/Code%20Style-Black-000000.svg)](https://github.com/psf/black)

A credit risk prediction system using CatBoost to predict loan defaults and optimize lending decisions for maximum profitability.

---

## 🎯 Overview

- **Predict loan defaults** with high accuracy (ROC-AUC: 0.82)
- **Optimize decision thresholds** to maximize business profit
- **Model interpretability** through SHAP analysis
- **Quantify business impact** across cost scenarios

### Dataset
- **Source**: German Credit Dataset
- **Records**: 1,000 loan applications
- **Features**: 9 features (5 categorical, 4 numerical)
- **Class Distribution**: ~30% default rate

---

## 🚀 Installation

```bash
# Clone repository
git clone <repository-url>
cd test_case_fairmoney

# Install dependencies
poetry install

# Activate environment
poetry shell
```

---

## 📓 Notebooks

This project contains two separate tasks:

### Task 1: `notebooks/task_1/`
Extract potential features for task 1

### Task 2: `notebooks/task_2/` - **Credit Risk Modeling**

Complete credit risk prediction pipeline:

#### 1. **Data Collection** - `1_data_collection.ipynb`
- Load and explore German Credit dataset
- Analyze class distribution and data quality

#### 2. **Data Processing** - `2_data_process.ipynb`
- Feature engineering (temporal features, risk indicators)
- Handle missing values and encode features

#### 3. **EDA** - `3_eda.ipynb`
- Categorical and numerical feature analysis
- Correlation analysis and feature selection

#### 4. **Train/Test Split** - `4_train_test.ipynb`
- Stratified split: 70% train, 10% val, 20% test
- Verify class balance across splits

#### 5. **Logistic Regression Baseline** - `5_logistic_regression_baseline.ipynb`
- Train baseline with WOE encoding
- Establish performance benchmark

#### 6. **CatBoost Baseline** - `6_1_catboost.ipynb`
- Train CatBoost with all features
- Overfitting analysis and feature selection

#### 7. **CatBoost Optimized** - `6_3_catboost_optimized.ipynb`
- Train with optimized hyperparameters
- Final model performance evaluation

#### 8. **Model Explanation** - `8_model_explaination.ipynb`
- SHAP analysis for interpretability
- Individual prediction explanations

#### 9. **Business Impact** - `9_business_impact.ipynb`
- Threshold optimization for profit
- Financial impact analysis

---

## 📊 Results

### Model Performance (Test Set)
- **ROC-AUC**: 0.82
- **Precision**: 0.62
- **Recall**: 0.95
- **F1-Score**: 0.75

### Feature Importance (Top 5)
1. checking_balance
2. credit_history
3. amount
4. savings_balance
5. employment_months

---

## 💰 Business Impact

### No Model vs. With Model

| Metric | No Model | With Model | Change |
|--------|----------|------------|--------|
| **Defaults Approved** | 60 | 3 | **-95%** ✅ |
| **Approval Rate** | 100% | 26.5% | -73.5% |

### Financial Impact (Moderate Scenario)

| Scenario | No Model | With Model | Improvement |
|----------|----------|------------|-------------|
| **Conservative** | $1,000 | $1,300 | +$300 |
| **Moderate** | -$114,500 | $3,400 | **+$117,900** 🎉 |
| **Aggressive** | -$230,000 | $5,500 | **+$235,500** 🚀 |

**Key Insight**: Model transforms $114k loss into $3.4k profit in moderate scenario.

---

## 🛠️ Technical Stack

- **Python 3.9+**
- **CatBoost** - Gradient boosting
- **SHAP** - Model interpretability
- **Pandas, NumPy** - Data processing
- **Scikit-learn** - ML utilities
- **Matplotlib, Seaborn** - Visualization
- **Poetry** - Dependency management

---

## 📂 Project Structure
```
.
├── data
│   ├── raw
│   ├── processed
│   └── external
├── notebooks
│   ├── task_1
│   └── task_2
├── src
│   ├── __init__.py
│   ├── data
│   │   ├── __init__.py
│   │   ├── make_dataset.py
│   │   └── load_data.py
│   ├── features
│   │   ├── __init__.py
│   │   └── build_features.py
│   ├── models
│   │   ├── __init__.py
│   │   ├── train_model.py
│   │   └── predict_model.py
│   ├── evaluation
│   │   ├── __init__.py
│   │   └── evaluate_model.py
│   └── utils
│       ├── __init__.py
│       └── helpers.py
├── tests
│   ├── __init__.py
│   └── test_basic.py
├── .gitignore
├── README.md
└── pyproject.toml
```

- **data/**: Contains raw, processed, and external datasets.
- **notebooks/**: Jupyter notebooks for exploratory data analysis and model development.
  - **task_1/**: Extract potential features for task 1
  - **task_2/**: Main credit risk analysis.
- **src/**: Source code for the project.
  - **data/**: Scripts for loading and processing data.
  - **features/**: Scripts for feature engineering.
  - **models/**: Scripts for training and predicting with models.
  - **evaluation/**: Scripts for evaluating model performance.
  - **utils/**: Utility functions and helpers.
- **tests/**: Unit tests for the project.
- **.gitignore**: Git ignore file.
- **README.md**: This README file.
- **pyproject.toml**: Poetry configuration file.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Key Features](#key-features)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Usage](#usage)
- [Notebooks](#notebooks)
- [Results](#results)
- [Business Impact](#business-impact)
- [Technical Stack](#technical-stack)
- [Contributing](#contributing)
